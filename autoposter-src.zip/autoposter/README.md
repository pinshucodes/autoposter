# Autoposter bot – source layout

Put this whole `src/` folder in your project and keep `main = "src/index.js"` in `wrangler.toml`.
(`package.json` is only here so the files can be tested locally with Node – Cloudflare ignores it.)

| File | What's inside |
|---|---|
| `index.js` | Front door only: Mini App pages, `/get/` redirect, `/api/`, webhook, cron |
| `messages.js` | Private chat messages and owner commands (`/start`, `/settings`, `/post`, `/digest`, `/test` …) |
| `buttons.js` | Every inline button tap |
| `posts.js` | Uploads from source channels → channel posts (movies, series, PDFs) |
| `parser.js` | Filename → title / season / episode / quality / language |
| `media.js` | TMDb + OMDb lookup, channel post caption and buttons |
| `delivery.js` | Sending files to users: verification gate, ForceSub check, auto-delete, file picker |
| `shortlink.js` | Bot username, deep links, shortlink API, verification message |
| `menus.js` | All `/settings` menus |
| `settings.js` | Values the owner types into settings, channel checks |
| `broadcast.js` | `/post` channel picker and broadcast engine |
| `payments.js` | Telegram Stars payments, `/skipads` |
| `subscriptions.js` | Premium plans and expiry |
| `miniapp.js` | Mini App security check and JSON API |
| `pages.js` | HTML of the two Mini Apps |
| `stats.js` | `/stats` and `/status` |
| `cron.js` | The every-minute job |
| `users.js`, `alerts.js` | User records, rate limit, owner alerts |
| `db.js`, `config.js`, `utils.js`, `telegram.js` | Shared building blocks |
| `digest.js`, `testmode.js` | Your existing modules (`digest.js` fixed, `testmode.js` unchanged) |

Rule of thumb for adding code: a new command goes in `messages.js`, a new button in `buttons.js`,
a new setting screen in `menus.js` (+ `buttons.js` for its taps).
