// src/messages.js - Private chat messages and owner commands

import { askConfirm } from "./broadcast.js";
import { MAIN_MENU, PLANS, ROLES } from "./config.js";
import { addChannel, clearState, getBatchRow, getChannels, getFileRow, getSetting, getState, setSetting, setState } from "./db.js";
import { deliverBatch, deliverFile } from "./delivery.js";
import { sendDailyDigest } from "./digest.js";
import { handleStarsPaid, sendSkipAds } from "./payments.js";
import { handleChannelPost } from "./posts.js";
import { checkChannel, extractChannelRef, handleSettingInput } from "./settings.js";
import { sendStats, sendStatus } from "./stats.js";
import { activateSubscription } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { handleTestCommand } from "./testmode.js";
import { isRateLimited, recordUser } from "./users.js";
import { MIN_VERIFY_SECONDS, dayString, esc, fmtDate } from "./utils.js";

// ---------- Handling messages ----------
export async function handleMessage(msg, env) {
  if (msg.chat.type !== "private") {
    await handleChannelPost(msg, env);
    return;
  }
  if (!msg.from) return;

  if (msg.successful_payment) {
    await handleStarsPaid(env, msg);
    return;
  }

  const text = msg.text || "";
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const isOwner = userId === String(env.OWNER_ID);

  const banned = await recordUser(env, msg.from);
  if (!isOwner) {
    if (banned) return;
    if (await isRateLimited(env, userId, chatId)) return;
  }

  if (text.startsWith("/start")) {
    // 1. Returning from Shortlink Verification: /start v<token>
    const tok = text.match(/^\/start v([A-Za-z0-9]+)/);
    if (tok) {
      const t = await env.DB.prepare("SELECT file_row_id, user_id, created FROM tokens WHERE token = ?")
        .bind(tok[1]).first();
      const fresh = t && Date.now() - t.created < 60 * 60 * 1000;
      if (!t || String(t.user_id) !== userId || !fresh) {
        await tg(env, "sendMessage", {
          chat_id: chatId,
          text: "⚠️ This verification link is invalid or has expired. Please tap the button on the channel post again.",
          parse_mode: "HTML",
        });
        return;
      }
      if (Date.now() - t.created < MIN_VERIFY_SECONDS * 1000) {
        await tg(env, "sendMessage", {
          chat_id: chatId,
          text: "⚠️ Bypass detected! Please complete the verification steps properly without skipping.",
        });
        return;
      }
      const used = await env.DB.prepare("DELETE FROM tokens WHERE token = ?").bind(tok[1]).run();
      if (!used.meta.changes) return;
      await env.DB.prepare("INSERT INTO verifications (user_id, file_row_id, day) VALUES (?, ?, ?)")
        .bind(userId, Math.abs(t.file_row_id), dayString(0)).run();

      // Negative file_row_id means it's a TV Series Season Batch
      if (t.file_row_id < 0) {
        const batch = await getBatchRow(env, -t.file_row_id);
        if (!batch) {
          await tg(env, "sendMessage", { chat_id: chatId, text: "Sorry, that season batch is no longer available." });
        } else {
          await deliverBatch(env, chatId, msg.from.id, batch, true);
        }
      } else {
        const row = await getFileRow(env, t.file_row_id);
        if (!row) {
          await tg(env, "sendMessage", { chat_id: chatId, text: "Sorry, that file is no longer available." });
        } else {
          await deliverFile(env, chatId, msg.from.id, row, true);
        }
      }
      return;
    }

    // 2. Opening a Series Season Quality Batch from Channel: /start b12
    const bMatch = text.match(/^\/start b(\d+)/);
    if (bMatch) {
      const batch = await getBatchRow(env, Number(bMatch[1]));
      if (!batch) {
        await tg(env, "sendMessage", { chat_id: chatId, text: "Sorry, that season batch is no longer available." });
      } else {
        await deliverBatch(env, chatId, msg.from.id, batch, false);
      }
      return;
    }

    // 3. Opening a Movie / Single File from Channel: /start f12
    const match = text.match(/^\/start f(\d+)/);
    if (match) {
      const row = await getFileRow(env, Number(match[1]));
      if (!row) {
        await tg(env, "sendMessage", { chat_id: chatId, text: "Sorry, that file is no longer available." });
      } else {
        await deliverFile(env, chatId, msg.from.id, row, false);
      }
      return;
    }

    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: "👋 Hi! Select any quality button on our channel posts to get your Movie or Series Season instantly.\n\nOwner can use /settings to configure me.",
    });
    return;
  }

  if (/^\/(skipads|premium)(\s|@|$)/.test(text)) {
    await sendSkipAds(env, chatId, userId);
    return;
  }

  if (!isOwner) return;

  if (/^\/grant(\s|$)/.test(text)) {
    const [, target, planKey] = text.split(/\s+/);
    if (!/^\d{5,15}$/.test(target || "") || !PLANS[planKey]) {
      await tg(env, "sendMessage", { chat_id: chatId, text: "Use it like this: /grant 123456789 month\nPlans: week, month, two, year" });
      return;
    }
    const exp = await activateSubscription(env, target, planKey);
    await tg(env, "sendMessage", { chat_id: chatId, text: `✅ Premium for ${target} until ${fmtDate(exp)}.` });
    await tg(env, "sendMessage", { chat_id: target, text: `⭐ Premium activated until ${fmtDate(exp)}. Enjoy ad-free downloads!` });
    return;
  }

  if (/^\/revoke(\s|$)/.test(text)) {
    const target = text.split(/\s+/)[1] || "";
    const r = await env.DB.prepare("DELETE FROM subscriptions WHERE user_id = ?").bind(target).run();
    await tg(env, "sendMessage", { chat_id: chatId, text: r.meta.changes ? `Premium removed for ${target}.` : "That user has no premium plan." });
    return;
  }

  if (text.startsWith("/status")) {
    await clearState(env, userId);
    await sendStatus(env, chatId);
    return;
  }

  if (/^\/(ban|unban)(\s|$)/.test(text)) {
    const unban = text.startsWith("/unban");
    const target = text.split(/\s+/)[1] || "";
    if (!/^\d{5,15}$/.test(target)) {
      await tg(env, "sendMessage", { chat_id: chatId, text: "Use it like this: /ban 123456789 (or /unban 123456789)" });
      return;
    }
    if (target === String(env.OWNER_ID)) {
      await tg(env, "sendMessage", { chat_id: chatId, text: "You can't ban yourself." });
      return;
    }
    await env.DB.prepare(
      "INSERT INTO users (user_id, first_name, joined_day, last_seen, banned, active) VALUES (?, '', ?, 0, ?, 0) " +
      "ON CONFLICT(user_id) DO UPDATE SET banned = excluded.banned"
    ).bind(target, dayString(0), unban ? 0 : 1).run();
    await tg(env, "sendMessage", { chat_id: chatId, text: `${unban ? "✅ Unbanned" : "🚫 Banned"} user ${target}.` });
    return;
  }

  if (text.startsWith("/stopbroadcast")) {
    const r = await env.DB.prepare("UPDATE broadcasts SET status = 'cancelled' WHERE status = 'running'").run();
    await tg(env, "sendMessage", { chat_id: chatId, text: r.meta.changes ? "🛑 Broadcast stopped." : "No broadcast is running." });
    return;
  }
  
  if (text.startsWith("/test")) {
    await clearState(env, userId);
    await handleTestCommand(env, chatId, text, { tg, getSetting, setSetting });
    return;
  }
  
  if (text.startsWith("/digest")) {
    await clearState(env, userId);
    const res = await sendDailyDigest(env, { tg, getChannels, getSetting, setSetting });
    const messageText = res.ok 
      ? `${res.isTestMode ? "🧪 Test Mode: " : ""}✅ Daily Digest posted to ${res.sentCount} channel(s) (${res.totalUploads} titles).`
      : `⚠️ Could not post digest: ${res.reason}`;
    await tg(env, "sendMessage", { chat_id: chatId, text: messageText });
    return;
  }
  
  if (text.startsWith("/stats")) {
    await clearState(env, userId);
    await sendStats(env, chatId);
    return;
  }

  if (text.startsWith("/post")) {
    await setState(env, userId, "post");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: "📣 Send the message you want to post (text, photo, video, file, anything). I'll ask you to confirm before it goes out.\n\n/cancel to stop.",
    });
    return;
  }

  if (text.startsWith("/broadcast")) {
    await setState(env, userId, "broadcast");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: "📢 Send the message you want to broadcast to all bot users (text, photo, video, file, anything). I'll ask you to confirm first.\n\n/cancel to stop.",
    });
    return;
  }

  if (text.startsWith("/settings")) {
    await clearState(env, userId);
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: MAIN_MENU.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: MAIN_MENU.buttons },
      reply_to_message_id: msg.message_id,
    });
    return;
  }

  if (text.startsWith("/cancel")) {
    await clearState(env, userId);
    await tg(env, "sendMessage", { chat_id: chatId, text: "Cancelled." });
    return;
  }

  const state = await getState(env, userId);
  if (state === "post" || state === "broadcast") {
    await askConfirm(env, msg, state);
    return;
  }
  if (state && state.startsWith("set:")) {
    await handleSettingInput(env, msg, state.split(":")[1]);
    return;
  }
  if (state && state.startsWith("add:")) {
    const role = state.split(":")[1];
    const ref = extractChannelRef(msg);
    if (!ref) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: "Please forward any message from the channel, or send its ID (like -1001234567890) or @username.\nSend /cancel to stop.",
      });
      return;
    }
    const result = await checkChannel(env, ref, role);
    if (result.error) {
      await tg(env, "sendMessage", { chat_id: chatId, text: "⚠️ " + result.error, parse_mode: "HTML" });
      return;
    }
    await addChannel(env, role, result.id, result.title, result.link);
    await clearState(env, userId);
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: `✅ Saved <b>${esc(result.title)}</b> as ${ROLES[role].name}.`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: `Open ${ROLES[role].name}`, callback_data: `role:${role}:new` }]],
      },
    });
  }
}
