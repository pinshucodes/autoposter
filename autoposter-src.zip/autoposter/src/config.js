// src/config.js - Fixed settings: channel roles, premium plans, settings-menu layout, shared runtime values


// ---------- Channel settings we manage ----------
export const ROLES = {
  source: {
    emoji: "📥", name: "Source Channels", multi: true,
    help: "Channels or groups where you upload your files. I watch these for new files. (For a group, make me an admin so I can see the files. Only group admins can add files.)",
  },
  lectures: {
    emoji: "🎬", name: "Movies / Series Channel", multi: true, max: 50,
    help: "The main channel where movie and series posts will be published and auto-updated.",
  },
  pdfs: {
    emoji: "📄", name: "PDFs Channel", multi: false,
    help: "The channel where PDF posts will be published.",
  },
  forcesub: {
    emoji: "🔐", name: "ForceSub Channels", multi: true,
    help: "Users must join all of these before they can get a file. Make me an admin in each one (with Invite Users permission for private channels). No channels = ForceSub is off.",
  },
};

// ---------- Menus ----------
export const MAIN_MENU = {
  text: "⚙️ <b>Settings</b>\n\nSelect what you want to configure:",
  buttons: [
    [{ text: "📥 Source Channels", callback_data: "role:source" }],
    [{ text: "🎬 Movies / Series Channel", callback_data: "role:lectures" }],
    [{ text: "📄 PDFs Channel", callback_data: "role:pdfs" }],
    [{ text: "🔐 ForceSub Settings", callback_data: "role:forcesub" }],
    [{ text: "🎬 IMDb, TMDb, Grouping & Shield", callback_data: "meta:menu" }],
    [{ text: "🔗 Shortlink & Tutorial Settings", callback_data: "sl:menu" }],
    [{ text: "🗑️ File Delete Settings", callback_data: "del:menu" }],
    [{ text: "🖼️ Cover Images", callback_data: "cov:menu" }],
    [{ text: "💳 Payments", callback_data: "pay:menu" }],
    [{ text: "❌ Close", callback_data: "close" }],
  ],
};

export const SUB_MENUS = {};

export const BACK_BUTTON = [[{ text: "⬅️ Back", callback_data: "back" }]];

// ---------- Subscriptions (skip ads) ----------
export const PLANS = {
  week: { name: "1 Week", price: 20, days: 7 },
  month: { name: "1 Month", price: 60, days: 30 },
  two: { name: "2 Months", price: 100, days: 60 },
  year: { name: "1 Year", price: 500, days: 365 },
};

export const STAR_DEFAULTS = { week: 12, month: 35, two: 58, year: 290 };

// Values that are filled in while the worker runs (modules cannot reassign each other's variables).
export const runtime = {
  appOrigin: null, // set from the incoming request URL, used for Mini App and redirect links
};
