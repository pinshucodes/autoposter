// src/utils.js - Small helpers used everywhere (HTML escaping, sizes, dates, constants)


export const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function formatSize(bytes) {
  if (!bytes) return "Unknown";
  const mb = bytes / (1024 * 1024);
  return mb >= 1024 ? (mb / 1024).toFixed(2) + " GB" : mb.toFixed(0) + " MB";
}

// ---------- File delete settings menu ----------
export function formatDelay(mins) {
  if (!mins) return "Off";
  if (mins >= 60 && mins % 60 === 0) {
    const h = mins / 60;
    return h === 1 ? "1 hour" : `${h} hours`;
  }
  return `${mins} min`;
}

// ---------- Users, stats, post and broadcast ----------
export const TZ_OFFSET_MIN = 330;

export const MIN_VERIFY_SECONDS = 10;

export const RATE_MAX = 8;

export const RATE_WINDOW_MS = 10000;

export function dayString(daysAgo) {
  const t = Date.now() + TZ_OFFSET_MIN * 60000 - daysAgo * 86400000;
  return new Date(t).toISOString().slice(0, 10);
}

export function fmtDate(ms) {
  return new Date(ms + TZ_OFFSET_MIN * 60000).toISOString().slice(0, 10);
}

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

// ---------- Build Channel Post Caption & Inline Keyboard ----------
export const QUALITY_ORDER = ["360p", "480p", "720p", "1080p", "1440p", "2160p 4K", "HD"];

export function sortQualities(a, b) {
  const ia = QUALITY_ORDER.indexOf(a);
  const ib = QUALITY_ORDER.indexOf(b);
  return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
}

// ---------- Constant-time string compare for webhook & HMAC ----------
export function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}
