// src/miniapp.js - Mini App security check and JSON API

import { PLANS } from "./config.js";
import { getSetting } from "./db.js";
import { getBotUsername, shortenUrl } from "./shortlink.js";
import { getStarPrices, getSubExpiry, starsEnabled } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { esc, fmtDate, json, safeEqual } from "./utils.js";

// ---------- Mini App security ----------
export async function hmacSha256(key, data) {
  const k = await crypto.subtle.importKey(
    "raw", typeof key === "string" ? new TextEncoder().encode(key) : key,
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  return new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(data)));
}

export async function verifyInitData(env, initData) {
  if (!initData || initData.length > 4096) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");
  const check = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const secret = await hmacSha256("WebAppData", env.BOT_TOKEN);
  const sig = [...(await hmacSha256(secret, check))].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (!safeEqual(sig, hash)) return null;
  if (Date.now() / 1000 - Number(params.get("auth_date") || 0) > 86400) return null;
  try {
    const user = JSON.parse(params.get("user"));
    return user && Number.isInteger(user.id) ? user : null;
  } catch (err) {
    return null;
  }
}

// ---------- Mini App API ----------
export async function handleApi(request, env, path) {
  if (request.method !== "POST") return json({ error: "Not allowed" }, 405);
  const user = await verifyInitData(env, request.headers.get("X-Init-Data") || "");
  if (!user) return json({ error: "auth" }, 401);
  const uid = String(user.id);

  const ban = await env.DB.prepare("SELECT banned FROM users WHERE user_id = ?").bind(uid).first();
  if (ban && ban.banned) return json({ error: "Your account can't use this." }, 403);

  let body = {};
  try { body = await request.json(); } catch (err) { /* empty body is fine */ }

  // Anti-Bypass Shortlink Generator inside Telegram Mini App
  if (path === "/api/verify-link") {
    const tok = String(body.token || "").trim();
    const t = await env.DB.prepare("SELECT token, user_id, file_row_id, created FROM tokens WHERE token = ?")
      .bind(tok).first();
    if (!t || String(t.user_id) !== uid || Date.now() - t.created > 3600 * 1000) {
      return json({ error: "This verification session has expired. Please tap the button in the bot again." }, 400);
    }
    // Reset timer to the exact moment the user opened the verification mini-app
    await env.DB.prepare("UPDATE tokens SET created = ? WHERE token = ?").bind(Date.now(), tok).run();
    const username = await getBotUsername(env);
    const short = await shortenUrl(env, `https://t.me/${username}?start=v${tok}`);
    if (!short) return json({ error: "Verification server is busy. Please try again." }, 500);
    return json({ url: short });
  }

  const upiId = await getSetting(env, "upi_id");

  if (path === "/api/me") {
    const until = await getSubExpiry(env, uid);
    const w = await env.DB.prepare(
      "SELECT id, plan, amount FROM payments WHERE user_id = ? AND status = 'submitted' ORDER BY id DESC LIMIT 1"
    ).bind(uid).first();
    const starPrices = await getStarPrices(env);
    return json({
      premium_until: until ? fmtDate(until) : null,
      upi_ready: !!upiId,
      stars_ready: await starsEnabled(env),
      plans: Object.entries(PLANS).map(([key, p]) => ({ key, name: p.name, price: p.price, days: p.days, stars: starPrices[key] })),
      waiting: w ? { plan_name: PLANS[w.plan].name, amount: w.amount } : null,
    });
  }

  if (path === "/api/pay") {
    if (!upiId) return json({ error: "Payments aren't set up yet." }, 400);
    const plan = PLANS[body.plan];
    if (!plan) return json({ error: "Unknown plan." }, 400);
    const recent = await env.DB.prepare("SELECT COUNT(*) AS n FROM payments WHERE user_id = ? AND created > ?")
      .bind(uid, Date.now() - 3600000).first();
    if (recent.n >= 8) return json({ error: "Too many attempts. Please try again in a while." }, 429);

    const ins = await env.DB.prepare(
      "INSERT INTO payments (user_id, plan, amount, status, created) VALUES (?, ?, ?, 'pending', ?)"
    ).bind(uid, body.plan, plan.price, Date.now()).run();
    const payee = (await getSetting(env, "upi_name")) || "Premium";
    const link = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payee)}` +
      `&am=${plan.price}.00&cu=INR&tn=${encodeURIComponent("Premium " + plan.name)}`;
    return json({ id: ins.meta.last_row_id, plan: plan.name, amount: plan.price, upi_id: upiId, payee, link });
  }

  if (path === "/api/stars") {
    if (!(await starsEnabled(env))) return json({ error: "Stars payments aren't available right now." }, 400);
    const plan = PLANS[body.plan];
    if (!plan) return json({ error: "Unknown plan." }, 400);
    const recent = await env.DB.prepare("SELECT COUNT(*) AS n FROM payments WHERE user_id = ? AND created > ?")
      .bind(uid, Date.now() - 3600000).first();
    if (recent.n >= 8) return json({ error: "Too many attempts. Please try again in a while." }, 429);

    const stars = (await getStarPrices(env))[body.plan];
    const ins = await env.DB.prepare(
      "INSERT INTO payments (user_id, plan, amount, status, method, created) VALUES (?, ?, ?, 'pending', 'stars', ?)"
    ).bind(uid, body.plan, stars, Date.now()).run();
    const inv = await tg(env, "createInvoiceLink", {
      title: `Premium - ${plan.name}`,
      description: `Skip the ads for ${plan.name}. Active right after payment.`,
      payload: `pay:${ins.meta.last_row_id}`,
      currency: "XTR",
      prices: [{ label: plan.name, amount: stars }],
    });
    if (!inv.ok) {
      console.log("Invoice failed:", inv.description);
      return json({ error: "Couldn't start the payment. Please try again." }, 500);
    }
    return json({ link: inv.result, stars });
  }

  if (path === "/api/utr") {
    const utr = String(body.utr || "").trim();
    if (!/^[0-9]{12}$/.test(utr)) return json({ error: "The reference number (UTR) is 12 digits. Please check and try again." }, 400);
    const pay = await env.DB.prepare("SELECT * FROM payments WHERE id = ? AND user_id = ?").bind(Number(body.id), uid).first();
    if (!pay || pay.status !== "pending") return json({ error: "This payment can't be updated." }, 400);
    try {
      const upd = await env.DB.prepare("UPDATE payments SET utr = ?, status = 'submitted' WHERE id = ? AND status = 'pending'")
        .bind(utr, pay.id).run();
      if (!upd.meta.changes) return json({ error: "This payment can't be updated." }, 400);
    } catch (err) {
      return json({ error: "This reference number was already used." }, 400);
    }
    const plan = PLANS[pay.plan];
    await tg(env, "sendMessage", {
      chat_id: env.OWNER_ID,
      text: `💳 <b>Payment to approve</b>\n\nUser: <code>${esc(uid)}</code> ${esc(user.first_name || "")}\nPlan: ${esc(plan.name)} (₹${plan.price})\nUTR: <code>${esc(utr)}</code>\n\nCheck your bank or UPI app for ₹${plan.price} with this reference number before approving.`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ Approve", callback_data: `pay:ok:${pay.id}` },
          { text: "❌ Reject", callback_data: `pay:no:${pay.id}` },
        ]],
      },
    });
    return json({ ok: true });
  }

  return json({ error: "Not found" }, 404);
}
