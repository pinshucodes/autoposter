// src/delivery.js - Sending files / batches to users: verification gate, ForceSub, auto-delete

import { alertOwner } from "./alerts.js";
import { getChannels, getFileRow, getSetting, setSetting } from "./db.js";
import { sendVerifyLink, shortlinkReady } from "./shortlink.js";
import { hasActiveSub } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { dayString, esc, formatDelay, formatSize } from "./utils.js";

// Sends a single file to the user (unlocked by default so they can share/forward within 5 mins)
export async function sendFileToUser(env, chatId, row, skipNotice) {
  const asVideo = row.send_as === "video";
  const protect = (await getSetting(env, "protect_files")) === "1"; // OFF by default so users can forward/share
  const sent = await tg(env, asVideo ? "sendVideo" : "sendDocument", {
    chat_id: chatId,
    [asVideo ? "video" : "document"]: row.file_id,
    caption: `🎬 <b>${esc(row.title)}</b>` + (row.size ? `\n📦 <b>Size:</b> ${formatSize(row.size)}` : ""),
    parse_mode: "HTML",
    protect_content: protect,
  });

  if (!sent.ok) {
    console.log("Send file failed:", sent.error_code, sent.description);
    if (sent.error_code !== 403 && !skipNotice) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: "⚠️ I couldn't send the file right now. Please try again in a minute.",
      });
      await alertOwner(env, `send${row.id}`, `Could not send file #${row.id} "${row.title}": ${sent.description}`);
    }
    return null;
  }

  await env.DB.prepare("INSERT INTO downloads (user_id, file_row_id, day) VALUES (?, ?, ?)")
    .bind(String(chatId), row.id, dayString(0)).run();

  // Default auto-delete is 5 minutes so users can forward/share before it vanishes
  const rawMins = await getSetting(env, "delete_minutes");
  const mins = rawMins === null ? 5 : parseInt(rawMins, 10);
  if (!mins) return sent.result.message_id;

  const deleteAt = Date.now() + mins * 60 * 1000;
  const ids = [sent.result.message_id];

  if (!skipNotice) {
    const notice = await tg(env, "sendMessage", {
      chat_id: chatId,
      text: `⏳ <b>Auto-Delete Notice:</b> This file will be deleted in <b>${formatDelay(mins)}</b>. Forward or share it to your Saved Messages now!`,
      parse_mode: "HTML",
    });
    if (notice.ok) ids.push(notice.result.message_id);
  }

  for (const id of ids) {
    await env.DB.prepare("INSERT INTO deletions (chat_id, message_id, delete_at) VALUES (?, ?, ?)")
      .bind(String(chatId), id, deleteAt).run();
  }
  return sent.result.message_id;
}

// Sends Paginated File / Episode Picker inside the bot (10 files per page + PREV/NEXT)
export async function sendBatchMenuToUser(env, chatId, batch, page = 0, editMsgId = null) {
  let items = [];
  try { items = JSON.parse(batch.items_json || "[]"); } catch (e) { items = []; }

  if (!items.length) {
    await tg(env, "sendMessage", { chat_id: chatId, text: "Sorry, no files found for this title." });
    return;
  }

  // Sort series by Season/Episode, or movies by size (largest to smallest)
  items.sort((a, b) => {
    if (a.episode || b.episode) {
      return (a.season || 1) - (b.season || 1) || (a.episode || 0) - (b.episode || 0) || (b.size || 0) - (a.size || 0);
    }
    return (b.size || 0) - (a.size || 0);
  });

  const perPage = 10;
  const totalPages = Math.ceil(items.length / perPage);
  const curPage = Math.max(0, Math.min(page, totalPages - 1));
  const slice = items.slice(curPage * perPage, (curPage + 1) * perPage);

  const lines = [
    `📁 <b>Found ✨ ${items.length} Files For : #${esc(batch.title)} 👇</b>`,
    `📄 <b>Page:</b> ${curPage + 1} of ${totalPages}`,
    "",
    `🔻 <b>Choose your file from the buttons below to start downloading</b> 🔻`,
  ];

  const buttons = [];

  for (const ep of slice) {
    const sizeStr = formatSize(ep.size);
    let label = ep.fileName || "";
    if (!label) {
      const sStr = ep.season ? `S${String(ep.season).padStart(2, "0")}` : "";
      const eStr = ep.episode ? `E${String(ep.episode).padStart(2, "0")}` : "";
      const seTag = (sStr || eStr) ? `${sStr}${eStr} • ` : "";
      const langTag = ep.audioLangs && ep.audioLangs.length ? ` • ${ep.audioLangs.join("+")}` : "";
      label = `${seTag}${ep.quality || "HD"}${langTag}`;
    }
    buttons.push([{
      text: `${sizeStr} - ${label}`.slice(0, 62),
      callback_data: `bep:${ep.rowId}`,
    }]);
  }

  if (totalPages > 1) {
    const navRow = [];
    if (curPage > 0) {
      navRow.push({ text: "⏪ PREVIOUS", callback_data: `bpage:${batch.batch_id}:${curPage - 1}` });
    }
    if (curPage < totalPages - 1) {
      navRow.push({ text: "⏩ NEXT", callback_data: `bpage:${batch.batch_id}:${curPage + 1}` });
    }
    if (navRow.length) buttons.push(navRow);
  }

  if (items.length > 1) {
    buttons.push([{ text: `📦 Send All ${items.length} Files`, callback_data: `ball:${batch.batch_id}` }]);
  }

  if (editMsgId) {
    await tg(env, "editMessageText", {
      chat_id: chatId,
      message_id: editMsgId,
      text: lines.join("\n"),
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons },
    });
    return;
  }

  const sent = await tg(env, "sendMessage", {
    chat_id: chatId,
    text: lines.join("\n"),
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons },
  });

  const rawMins = await getSetting(env, "delete_minutes");
  const mins = rawMins === null ? 5 : parseInt(rawMins, 10);
  if (mins && sent.ok) {
    await env.DB.prepare("INSERT INTO deletions (chat_id, message_id, delete_at) VALUES (?, ?, ?)")
      .bind(String(chatId), sent.result.message_id, Date.now() + mins * 60 * 1000).run();
  }
}

// Runs every minute (Cron Trigger)
export async function runDeletions(env, limit) {
  const due = await env.DB.prepare(
    "SELECT id, chat_id, message_id, attempts FROM deletions WHERE delete_at <= ? ORDER BY delete_at LIMIT ?"
  ).bind(Date.now(), limit).all();

  for (const d of due.results || []) {
    const r = await tg(env, "deleteMessage", { chat_id: d.chat_id, message_id: d.message_id });
    const finalAnswer = r.ok || r.error_code === 400 || r.error_code === 403;
    if (finalAnswer || d.attempts >= 8) {
      await env.DB.prepare("DELETE FROM deletions WHERE id = ?").bind(d.id).run();
    } else {
      await env.DB.prepare("UPDATE deletions SET attempts = attempts + 1, delete_at = ? WHERE id = ?")
        .bind(Date.now() + (d.attempts + 1) * 60000, d.id).run();
    }
  }
}

// ---------- ForceSub check ----------
export async function getMissingChannels(env, userId) {
  const channels = await getChannels(env, "forcesub");
  const checks = await Promise.all(channels.map(async (c) => {
    const r = await tg(env, "getChatMember", { chat_id: c.chat_id, user_id: userId });
    if (!r.ok) {
      if (/user not found|PARTICIPANT_ID_INVALID/i.test(r.description || "")) return c;
      await alertOwner(env, `fs${c.chat_id}`,
        `ForceSub can't check "${c.title}": ${r.description}. Make sure I'm still an admin there.`);
      return null;
    }
    const st = r.result.status;
    const joined = st === "member" || st === "administrator" || st === "creator" ||
      (st === "restricted" && r.result.is_member);
    return joined ? null : c;
  }));
  return checks.filter(Boolean);
}

export async function ensureLink(env, c) {
  if (c.link) return c.link;
  const chat = await tg(env, "getChat", { chat_id: c.chat_id });
  let link = chat.ok && chat.result.username ? `https://t.me/${chat.result.username}` : null;
  if (!link) {
    const inv = await tg(env, "exportChatInviteLink", { chat_id: c.chat_id });
    if (inv.ok) link = inv.result;
  }
  if (link) {
    await env.DB.prepare("UPDATE channels SET link = ? WHERE role = 'forcesub' AND chat_id = ?").bind(link, c.chat_id).run();
  } else {
    await alertOwner(env, `lnk${c.chat_id}`, `I have no join link for ForceSub channel "${c.title}". Give me Invite Users permission.`);
  }
  return link;
}

// Checks if user has verified within the last 6 hours (when 6-Hour Pass is ON)
export async function isVerifiedLast6Hours(env, userId, fileId) {
  if (await hasActiveSub(env, userId)) return true;

  const passEnabled = (await getSetting(env, "vpass_enabled")) !== "0"; // ON by default
  if (passEnabled) {
    const r = await env.DB.prepare("SELECT value FROM settings WHERE key = ?")
      .bind(`vpass_${userId}`).first();
    return Boolean(r && Number(r.value) > Date.now());
  }

  // If 6-Hour Pass is turned OFF, require verification for every movie/series
  return false;
}

// 1. Verify FIRST -> 2. Check ForceSub SECOND -> 3. Send File
export async function deliverFile(env, chatId, userId, row, justVerified, skipVerify = false) {
  if (justVerified) {
    await setSetting(env, `vpass_${userId}`, String(Date.now() + 6 * 3600 * 1000));
  }

  // STEP 1: Check Verification FIRST
  if (!justVerified && !skipVerify && (await shortlinkReady(env)) && !(await isVerifiedLast6Hours(env, userId, row.id))) {
    await sendVerifyLink(env, chatId, userId, row.id, row.title);
    return;
  }

  // STEP 2: After Verification, check ForceSub Channel(s)
  const missing = await getMissingChannels(env, userId);
  if (missing.length) {
    const buttons = [];
    for (const c of missing) {
      const link = await ensureLink(env, c);
      if (link) buttons.push([{ text: `📢 Join ${c.title}`.slice(0, 60), url: link }]);
    }
    buttons.push([{ text: "🔄 Try Again / Get File", callback_data: `chk:${row.id}` }]);
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: "✅ <b>Verification Complete!</b>\n\n🔐 Now join our backup channel(s) below and tap <b>Try Again / Get File</b> to receive your file instantly:",
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons },
    });
    return;
  }

  // STEP 3: Send the file (this also records the download and schedules the auto-delete)
  await sendFileToUser(env, chatId, row, false);
}

// 1. Verify FIRST -> 2. Check ForceSub SECOND -> 3. Open Episode/Quality Menu
export async function deliverBatch(env, chatId, userId, batch, justVerified, skipVerify = false) {
  if (justVerified) {
    await setSetting(env, `vpass_${userId}`, String(Date.now() + 6 * 3600 * 1000));
  }

  // STEP 1: Check Verification FIRST
  if (!justVerified && !skipVerify && (await shortlinkReady(env)) && !(await isVerifiedLast6Hours(env, userId, -batch.batch_id))) {
    await sendVerifyLink(env, chatId, userId, -batch.batch_id, batch.title);
    return;
  }

  // STEP 2: After Verification, check ForceSub Channel(s)
  const missing = await getMissingChannels(env, userId);
  if (missing.length) {
    const buttons = [];
    for (const c of missing) {
      const link = await ensureLink(env, c);
      if (link) buttons.push([{ text: `📢 Join ${c.title}`.slice(0, 60), url: link }]);
    }
    buttons.push([{ text: "🔄 Try Again / Get Files", callback_data: `chkb:${batch.batch_id}` }]);
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: "✅ <b>Verification Complete!</b>\n\n🔐 Now join our backup channel(s) below and tap <b>Try Again / Get Files</b> to unlock all files:",
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons },
    });
    return;
  }

  // STEP 3: Open the file picker (or send straight away when there is only one file)
  let items = [];
  try { items = JSON.parse(batch.items_json || "[]"); } catch (e) { items = []; }
  if (!items.length) {
    await tg(env, "sendMessage", { chat_id: chatId, text: "⚠️ No files found in this batch." });
    return;
  }

  if (items.length === 1) {
    const fRow = await getFileRow(env, items[0].rowId);
    if (fRow) {
      await sendFileToUser(env, chatId, fRow, false);
      return;
    }
  }

  await sendBatchMenuToUser(env, chatId, batch);
}
