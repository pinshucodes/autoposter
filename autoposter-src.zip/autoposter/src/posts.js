// src/posts.js - Handling uploads from source channels and publishing channel posts

import { ensureExtraTables, getChannels, getSetting, saveFile } from "./db.js";
import { buildChannelPostView, fetchMediaMeta } from "./media.js";
import { parseMediaFilename } from "./parser.js";
import { makeDeepLink } from "./shortlink.js";
import { tg } from "./telegram.js";
import { resolveTargetChannels } from "./testmode.js";
import { esc, formatSize } from "./utils.js";

export function classifyPost(post) {
  if (post.video) {
    return { kind: "lecture", send_as: "video", file: post.video, name: post.video.file_name || "" };
  }
  if (post.document) {
    const d = post.document;
    const name = d.file_name || "";
    const mime = d.mime_type || "";
    if (mime === "application/pdf" || /\.pdf$/i.test(name)) {
      return { kind: "pdf", send_as: "document", file: d, name };
    }
    if (mime.startsWith("video/") || /\.(mkv|mp4|avi|mov|webm|flv|m4v|ts)$/i.test(name)) {
      return { kind: "lecture", send_as: "document", file: d, name };
    }
  }
  return null;
}

export function makeTitle(post, name) {
  const caption = (post.caption || "").split("\n")[0].trim();
  if (caption) return caption;
  const cleaned = name.replace(/\.[^.]+$/, "").replace(/[._]+/g, " ").trim();
  return cleaned || "Untitled";
}

export async function isTrustedSender(env, post) {
  if (post.sender_chat && post.sender_chat.id === post.chat.id) return true;
  if (!post.from) return false;
  if (String(post.from.id) === String(env.OWNER_ID)) return true;
  const r = await tg(env, "getChatMember", { chat_id: post.chat.id, user_id: post.from.id });
  return r.ok && (r.result.status === "creator" || r.result.status === "administrator");
}

// ---------- Upsert Master Batch in D1 (Used for both Movies & Series) ----------
export async function upsertSeasonBatch(env, groupKey, quality, title, epEntry) {
  await ensureExtraTables(env);
  const existing = await env.DB.prepare(
    "SELECT batch_id, items_json FROM batches WHERE group_key = ? AND quality = ?"
  ).bind(groupKey, quality).first();

  if (!existing) {
    const items = epEntry ? [epEntry] : [];
    const ins = await env.DB.prepare(
      "INSERT INTO batches (group_key, quality, title, items_json, updated) VALUES (?, ?, ?, ?, ?)"
    ).bind(groupKey, quality, title, JSON.stringify(items), Date.now()).run();
    return ins.meta.last_row_id;
  }

  if (!epEntry) return existing.batch_id;

  let items = [];
  try { items = JSON.parse(existing.items_json || "[]"); } catch (e) { items = []; }

  const idx = items.findIndex((x) => x.rowId === epEntry.rowId);
  if (idx >= 0) items[idx] = epEntry;
  else items.push(epEntry);

  await env.DB.prepare(
    "UPDATE batches SET title = ?, items_json = ?, updated = ? WHERE batch_id = ?"
  ).bind(title, JSON.stringify(items), Date.now(), existing.batch_id).run();

  return existing.batch_id;
}

// ---------- Handling Source Channel Uploads ----------
export async function handleChannelPost(post, env) {
  const sources = await getChannels(env, "source");
  if (!sources.some((s) => String(s.chat_id) === String(post.chat.id))) return;
  if (!(await isTrustedSender(env, post))) return;

  const info = classifyPost(post);
  if (!info) return;

  const title = makeTitle(post, info.name);
  const rowId = await saveFile(env, {
    file_id: info.file.file_id,
    file_unique_id: info.file.file_unique_id,
    kind: info.kind,
    send_as: info.send_as,
    title,
    size: info.file.file_size || 0,
  });
  if (!rowId) return;

  if (info.kind === "pdf") {
    const rawPdfTargets = await getChannels(env, "pdfs");
    const { targets } = await resolveTargetChannels(env, rawPdfTargets, getSetting);
    if (!targets.length) return;
    const targetChat = targets[0].chat_id;
    const cover = await getSetting(env, "cover_pdf");
    const link = await makeDeepLink(env, `f${rowId}`);
    const caption = `📄 <b>${esc(title)}</b>\n📦 <b>Size:</b> ${formatSize(info.file.file_size)}`;
    const markup = { inline_keyboard: [[{ text: "📥 Download PDF", url: link }]] };

    if (cover) {
      await tg(env, "sendPhoto", {
        chat_id: targetChat, photo: cover, caption, parse_mode: "HTML", reply_markup: markup,
      });
    } else {
      await tg(env, "sendMessage", {
        chat_id: targetChat, text: caption, parse_mode: "HTML", reply_markup: markup,
      });
    }
    return;
  }

  const rawTargets = (await getChannels(env, "lectures")).slice(0, 50);
  const { isTestMode, targets } = await resolveTargetChannels(env, rawTargets, getSetting);
  if (!targets.length) return;
  await ensureExtraTables(env);
  const fullText = `${info.name || ""} ${post.caption || ""}`;
  const isSample = /\bsample\b/i.test(fullText);
  const parsed = parseMediaFilename(info.name, post.caption || "");
  if (isTestMode) parsed.groupKey = `test_${parsed.groupKey}`;
  const groupOn = (await getSetting(env, "group_qualities")) !== "0";
  const showMediaInfo = (await getSetting(env, "mediainfo_enabled")) !== "0";
  const existingPost = groupOn
    ? await env.DB.prepare("SELECT * FROM media_posts WHERE group_key = ?").bind(parsed.groupKey).first()
    : null;

  let meta = null;
  let items = [];
  let sampleRowId = null;

  if (existingPost) {
    try { meta = JSON.parse(existingPost.meta_json || "null"); } catch (e) { meta = null; }
    try { items = JSON.parse(existingPost.items_json || "[]"); } catch (e) { items = []; }
    if (meta && meta.sampleRowId) sampleRowId = meta.sampleRowId;
  } else {
    meta = await fetchMediaMeta(env, parsed);
  }
  if (!meta) {
    meta = {
      title: parsed.cleanTitle,
      year: parsed.year || "",
      rating: "",
      genres: "",
      plot: "",
      poster: "",
      type: parsed.isSeries ? "TV Series" : "Movie",
    };
  }

  const displayTitle = meta.title
    ? (parsed.isSeries ? `${meta.title} S${String(parsed.season || 1).padStart(2, "0")}` : `${meta.title}${meta.year ? " " + meta.year : ""}`)
    : (parsed.isSeries ? `${parsed.cleanTitle} S${String(parsed.season || 1).padStart(2, "0")}` : parsed.cleanTitle);

  let batchId = null;

  if (isSample) {
    sampleRowId = rowId;
    meta.sampleRowId = sampleRowId;
    batchId = await upsertSeasonBatch(env, parsed.groupKey, "ALL", displayTitle, null);
  } else {
    const newItem = {
      rowId,
      fileName: parsed.displayFileName,
      quality: parsed.quality,
      season: parsed.season,
      episode: parsed.episode,
      size: info.file.file_size || 0,
      source: parsed.source,
      vCodec: parsed.vCodec,
      aCodec: parsed.aCodec,
      audioLangs: parsed.audioLangs,
    };

    batchId = await upsertSeasonBatch(env, parsed.groupKey, "ALL", displayTitle, newItem);
    newItem.batchId = batchId;

    const idx = items.findIndex((x) => x.rowId === rowId);
    if (idx >= 0) items[idx] = newItem;
    else items.push(newItem);
  }

  meta.sampleRowId = sampleRowId;
  meta.batchId = batchId;

  const view = await buildChannelPostView(env, meta, parsed, items, showMediaInfo, sampleRowId, batchId);

  const chanMap = {};
  if (groupOn) {
    const chRows = await env.DB.prepare(
      "SELECT chat_id, message_id, has_photo FROM media_post_channels WHERE group_key = ?"
    ).bind(parsed.groupKey).all();
    for (const r of chRows.results || []) {
      chanMap[String(r.chat_id)] = { message_id: r.message_id, has_photo: r.has_photo };
    }
    if (existingPost && existingPost.chat_id && existingPost.message_id && !chanMap[String(existingPost.chat_id)]) {
      chanMap[String(existingPost.chat_id)] = {
        message_id: existingPost.message_id,
        has_photo: existingPost.has_photo,
      };
    }
  }

  const fallbackCover = await getSetting(env, "cover_lecture");
  let photoSource = (meta && meta.poster) || fallbackCover || null;
  let firstMsgId = existingPost ? existingPost.message_id : 0;
  let firstChatId = existingPost ? existingPost.chat_id : "";
  let firstHasPhoto = existingPost ? existingPost.has_photo : 0;
  let anySuccess = false;

  for (const t of targets) {
    const targetChat = String(t.chat_id);
    const prev = chanMap[targetChat];

    if (groupOn && prev && prev.message_id) {
      const editMethod = prev.has_photo ? "editMessageCaption" : "editMessageText";
      const editPayload = {
        chat_id: targetChat,
        message_id: prev.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: view.buttons },
      };
      if (prev.has_photo) editPayload.caption = view.caption;
      else editPayload.text = view.caption;

      const edited = await tg(env, editMethod, editPayload);
      if (edited.ok || /message is not modified/i.test(edited.description || "")) {
        anySuccess = true;
        continue;
      }
    }

    let sent = null;
    let hasPhoto = 0;

    if (photoSource) {
      sent = await tg(env, "sendPhoto", {
        chat_id: targetChat,
        photo: photoSource,
        caption: view.caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: view.buttons },
      });
      if (sent.ok) {
        hasPhoto = 1;
        if (sent.result.photo && sent.result.photo.length) {
          photoSource = sent.result.photo[sent.result.photo.length - 1].file_id;
        }
      }
    }

    if (!sent || !sent.ok) {
      sent = await tg(env, "sendMessage", {
        chat_id: targetChat,
        text: view.caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: view.buttons },
      });
    }

    if (sent && sent.ok) {
      anySuccess = true;
      if (!firstMsgId) {
        firstMsgId = sent.result.message_id;
        firstChatId = targetChat;
        firstHasPhoto = hasPhoto;
      }
      if (groupOn) {
        await env.DB.prepare(
          "INSERT OR REPLACE INTO media_post_channels (group_key, chat_id, message_id, has_photo) VALUES (?, ?, ?, ?)"
        ).bind(parsed.groupKey, targetChat, sent.result.message_id, hasPhoto).run();
      }
    }
  }

  if (anySuccess && groupOn) {
    await env.DB.prepare(
      "INSERT OR REPLACE INTO media_posts (group_key, chat_id, message_id, has_photo, meta_json, items_json, updated) " +
      "VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).bind(
      parsed.groupKey,
      String(firstChatId),
      firstMsgId,
      firstHasPhoto,
      JSON.stringify(meta),
      JSON.stringify(items),
      Date.now()
    ).run();
  }
}
