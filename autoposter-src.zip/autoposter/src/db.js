// src/db.js - D1 database helpers (tables, channels, state, files, batches, saved settings)

import { ROLES } from "./config.js";

// ---------- Auto-create tables for Multi-Quality & Series Season Batches ----------
let SCHEMA_READY = false;

export async function ensureExtraTables(env) {
  if (SCHEMA_READY) return;
  try {
    await env.DB.batch([
      env.DB.prepare(
        "CREATE TABLE IF NOT EXISTS media_posts (" +
        "group_key TEXT PRIMARY KEY, " +
        "chat_id TEXT, " +
        "message_id INTEGER, " +
        "has_photo INTEGER, " +
        "meta_json TEXT, " +
        "items_json TEXT, " +
        "updated INTEGER)"
      ),
      env.DB.prepare(
        "CREATE TABLE IF NOT EXISTS media_post_channels (" +
        "group_key TEXT, " +
        "chat_id TEXT, " +
        "message_id INTEGER, " +
        "has_photo INTEGER, " +
        "PRIMARY KEY (group_key, chat_id))"
      ),
      env.DB.prepare(
        "CREATE TABLE IF NOT EXISTS batches (" +
        "batch_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
        "group_key TEXT, " +
        "quality TEXT, " +
        "title TEXT, " +
        "items_json TEXT, " +
        "updated INTEGER)"
      ),
      env.DB.prepare(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_batches_gk_q ON batches(group_key, quality)"
      ),
    ]);
    SCHEMA_READY = true;
  } catch (err) {
    console.log("Table init note:", err);
  }
}

// ---------- Database helpers ----------
export async function getChannels(env, role) {
  const r = await env.DB.prepare("SELECT chat_id, title, link FROM channels WHERE role = ?").bind(role).all();
  return r.results || [];
}

export async function addChannel(env, role, chatId, title, link) {
  const steps = [];
  if (!ROLES[role].multi) {
    steps.push(env.DB.prepare("DELETE FROM channels WHERE role = ?").bind(role));
  }
  steps.push(
    env.DB.prepare("INSERT OR REPLACE INTO channels (role, chat_id, title, link) VALUES (?, ?, ?, ?)")
      .bind(role, String(chatId), title, link || null)
  );
  await env.DB.batch(steps);
}

export async function removeChannel(env, role, chatId) {
  await env.DB.prepare("DELETE FROM channels WHERE role = ? AND chat_id = ?").bind(role, String(chatId)).run();
}

export async function setState(env, userId, action) {
  await env.DB.prepare("INSERT OR REPLACE INTO state (user_id, action) VALUES (?, ?)").bind(String(userId), action).run();
}

export async function getState(env, userId) {
  const r = await env.DB.prepare("SELECT action FROM state WHERE user_id = ?").bind(String(userId)).first();
  return r ? r.action : null;
}

export async function clearState(env, userId) {
  await env.DB.prepare("DELETE FROM state WHERE user_id = ?").bind(String(userId)).run();
}

// ---------- Files we have seen in source channels ----------
export async function saveFile(env, f) {
  const r = await env.DB.prepare(
    "INSERT OR IGNORE INTO files (file_id, file_unique_id, kind, send_as, title, size) VALUES (?, ?, ?, ?, ?, ?)"
  ).bind(f.file_id, f.file_unique_id, f.kind, f.send_as, f.title, f.size).run();
  if (r.meta.changes > 0) return r.meta.last_row_id;
  const ex = await env.DB.prepare("SELECT id FROM files WHERE file_unique_id = ?").bind(f.file_unique_id).first();
  return ex ? ex.id : null;
}

export async function getFileRow(env, id) {
  return env.DB.prepare("SELECT * FROM files WHERE id = ?").bind(id).first();
}

export async function getBatchRow(env, batchId) {
  await ensureExtraTables(env);
  return env.DB.prepare("SELECT * FROM batches WHERE batch_id = ?").bind(batchId).first();
}

// ---------- Simple saved settings ----------
export async function getSetting(env, key) {
  const r = await env.DB.prepare("SELECT value FROM settings WHERE key = ?").bind(key).first();
  return r ? r.value : null;
}

export async function setSetting(env, key, value) {
  await env.DB.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)").bind(key, value).run();
}
