// src/stats.js - /stats and /status reports

import { getSetting } from "./db.js";
import { shortenUrl } from "./shortlink.js";
import { starsEnabled } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { dayString, esc, formatDelay } from "./utils.js";

export async function sendStats(env, chatId) {
  const today = dayString(0);
  const one = (sql, ...args) => env.DB.prepare(sql).bind(...args).first();

  const total = await one("SELECT COUNT(*) AS n FROM users");
  const active = await one("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND banned = 0");
  const banned = await one("SELECT COUNT(*) AS n FROM users WHERE banned = 1");
  const joined = await one("SELECT COUNT(*) AS n FROM users WHERE joined_day = ?", today);
  const ver = await one("SELECT COUNT(*) AS n, COUNT(DISTINCT user_id) AS u FROM verifications WHERE day = ?", today);
  const dl = await one("SELECT COUNT(*) AS n, COUNT(DISTINCT user_id) AS u FROM downloads WHERE day = ?", today);
  const files = await one("SELECT COUNT(*) AS n FROM files");
  const subs = await one("SELECT COUNT(*) AS n FROM subscriptions WHERE expires_at > ?", Date.now());

  const since = dayString(6);
  const vWeek = await env.DB.prepare("SELECT day, COUNT(*) AS n FROM verifications WHERE day >= ? GROUP BY day").bind(since).all();
  const dWeek = await env.DB.prepare("SELECT day, COUNT(*) AS n FROM downloads WHERE day >= ? GROUP BY day").bind(since).all();
  const v = {}, d = {};
  for (const r of vWeek.results || []) v[r.day] = r.n;
  for (const r of dWeek.results || []) d[r.day] = r.n;
  const lines = [];
  for (let i = 0; i < 7; i++) {
    const day = dayString(i);
    lines.push(`${day}: ${v[day] || 0} verified · ${d[day] || 0} delivered`);
  }

  const text =
    "📊 <b>Stats</b>\n\n" +
    `👥 Users: <b>${total.n}</b> (${active.n} reachable, ${banned.n} banned)\n` +
    `🆕 Joined today: <b>${joined.n}</b>\n` +
    `✅ Verifications today: <b>${ver.n}</b> (${ver.u} people)\n` +
    `📥 Files delivered today: <b>${dl.n}</b> (${dl.u} people)\n` +
    `📁 Total files indexed: <b>${files.n}</b>\n` +
    `⭐ Active subscribers: <b>${subs.n}</b>\n\n` +
    "📅 <b>Last 7 days</b>\n" + lines.join("\n") +
    "\n\n<i>Days follow India time (IST).</i>";
  await tg(env, "sendMessage", { chat_id: chatId, text, parse_mode: "HTML" });
}

export async function sendStatus(env, chatId) {
  const lines = [];

  const hook = await tg(env, "getWebhookInfo", {});
  if (hook.ok) {
    const h = hook.result;
    lines.push(`${h.url ? "✅" : "⚠️"} Webhook: ${h.url ? "set" : "NOT set"}, waiting updates: ${h.pending_update_count}`);
    if (h.allowed_updates && !h.allowed_updates.includes("pre_checkout_query")) {
      lines.push("⚠️ Webhook is not receiving payment updates. Re-run the setWebhook link with pre_checkout_query added, or Stars payments will fail.");
    }
    if (h.last_error_message) {
      const when = h.last_error_date ? new Date(h.last_error_date * 1000).toISOString().replace("T", " ").slice(0, 16) + " UTC" : "";
      lines.push(`⚠️ Last Telegram delivery error: ${esc(h.last_error_message)} ${when}`);
    }
  } else {
    lines.push(`⚠️ Can't reach Telegram: ${esc(hook.description || "unknown error")}`);
  }

  const lc = parseInt((await getSetting(env, "last_cron")) || "0", 10);
  const age = lc ? Math.round((Date.now() - lc) / 60000) : null;
  lines.push(age === null ? "⚠️ Cleanup job: hasn't run yet"
    : age <= 3 ? `✅ Cleanup job: ran ${age} min ago`
    : `⚠️ Cleanup job: last ran ${age} min ago (check the cron trigger)`);

  const q = await env.DB.prepare("SELECT COUNT(*) AS n, SUM(delete_at <= ?) AS due FROM deletions").bind(Date.now()).first();
  lines.push(`🗑 Deletions waiting: ${q.n} (${q.due || 0} due now)`);
  const job = await env.DB.prepare("SELECT * FROM broadcasts WHERE status = 'running' LIMIT 1").first();
  if (job) lines.push(`📢 Broadcast running: ${job.sent + job.failed} of ${job.total} done`);

  if ((await getSetting(env, "shortlink_enabled")) === "1") {
    const test = await shortenUrl(env, "https://t.me/telegram");
    lines.push(test ? "✅ Shortlink: working (Anti-Copy Shield ON)" : "⚠️ Shortlink: NOT working (users skip verification)");
  } else {
    lines.push("➖ Shortlink: off");
  }
  const metaOn = (await getSetting(env, "meta_enabled")) === "1";
  lines.push(metaOn ? "✅ IMDb/TMDb: on" : "➖ IMDb/TMDb: off");
  const groupOn = (await getSetting(env, "group_qualities")) !== "0";
  lines.push(groupOn ? "✅ Multi-Quality & Series Batching: on" : "➖ Grouping: off");
  const rawMins = await getSetting(env, "delete_minutes");
  const mins = rawMins === null ? 5 : parseInt(rawMins, 10);
  lines.push(`🛡️ Auto-delete: ${formatDelay(mins)}`);

  const upiId = await getSetting(env, "upi_id");
  const waiting = await env.DB.prepare("SELECT COUNT(*) AS n FROM payments WHERE status = 'submitted'").first();
  lines.push(upiId ? `✅ Payments: UPI set, ${waiting.n} waiting for your approval` : "➖ Payments: UPI ID not set");
  lines.push((await starsEnabled(env)) ? "✅ Payments: Stars on" : "➖ Payments: Stars off");

  const me = await tg(env, "getMe", {});
  const chans = await env.DB.prepare(
    "SELECT chat_id, title, GROUP_CONCAT(role) AS roles FROM channels GROUP BY chat_id ORDER BY title LIMIT 10"
  ).all();
  const rows = await Promise.all((chans.results || []).map(async (c) => {
    const r = me.ok ? await tg(env, "getChatMember", { chat_id: c.chat_id, user_id: me.result.id }) : null;
    let mark = "✅", note = "";
    if (!r || !r.ok || r.result.status !== "administrator") { mark = "⚠️"; note = " - I'm not an admin there"; }
    else if (r.result.can_post_messages === false && /lectures|pdfs/.test(c.roles)) { mark = "⚠️"; note = " - I can't post there"; }
    return `${mark} ${esc(c.title)} (${esc(c.roles)})${note}`;
  }));
  if (rows.length) lines.push("\n<b>Channels</b>\n" + rows.join("\n"));

  await tg(env, "sendMessage", {
    chat_id: chatId,
    text: "🩺 <b>Status</b>\n\n" + lines.join("\n"),
    parse_mode: "HTML",
  });
}
