// src/payments.js - Telegram Stars payments and /skipads

import { alertOwner } from "./alerts.js";
import { PLANS, runtime } from "./config.js";
import { activateSubscription, getSubExpiry } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { fmtDate } from "./utils.js";

// ---------- Telegram Stars ----------
export async function handlePreCheckout(q, env) {
  let ok = false;
  try {
    const m = /^pay:(\d+)$/.exec(q.invoice_payload || "");
    const pay = m ? await env.DB.prepare("SELECT * FROM payments WHERE id = ?").bind(Number(m[1])).first() : null;
    const ban = await env.DB.prepare("SELECT banned FROM users WHERE user_id = ?").bind(String(q.from.id)).first();
    ok = !!pay && pay.method === "stars" && pay.status === "pending" &&
      pay.user_id === String(q.from.id) && q.currency === "XTR" && q.total_amount === pay.amount &&
      !(ban && ban.banned);
  } catch (err) {
    console.log("Pre-checkout error:", String(err).split(env.BOT_TOKEN).join("***"));
  }
  await tg(env, "answerPreCheckoutQuery", ok
    ? { pre_checkout_query_id: q.id, ok: true }
    : { pre_checkout_query_id: q.id, ok: false, error_message: "Sorry, this payment can't be completed. Please try again." });
}

export async function handleStarsPaid(env, msg) {
  const sp = msg.successful_payment;
  if (sp.currency !== "XTR") return;
  const uid = String(msg.from.id);
  const charge = sp.telegram_payment_charge_id;
  try {
    const m = /^pay:(\d+)$/.exec(sp.invoice_payload || "");
    const pay = m ? await env.DB.prepare("SELECT * FROM payments WHERE id = ?").bind(Number(m[1])).first() : null;
    if (!pay || pay.method !== "stars" || pay.user_id !== uid) {
      await alertOwner(env, `stars_unknown${charge}`,
        `A Stars payment arrived that I can't match: user ${uid}, ${sp.total_amount} Stars, charge ID ${charge}. Please check it and use /grant if it's valid.`);
      return;
    }
    const claim = await env.DB.prepare(
      "UPDATE payments SET status = 'approved', utr = ?, decided = ? WHERE id = ? AND status = 'pending'"
    ).bind(`stars:${charge}`, Date.now(), pay.id).run();
    if (!claim.meta.changes) return;

    const exp = await activateSubscription(env, uid, pay.plan);
    const plan = PLANS[pay.plan];
    await tg(env, "sendMessage", { chat_id: uid, text: `✅ Payment received! Premium is active until ${fmtDate(exp)}. Enjoy ad-free downloads.` });
    await tg(env, "sendMessage", {
      chat_id: env.OWNER_ID,
      text: `⭐ New Stars payment: user ${uid}, ${plan.name}, ${pay.amount} Stars. Premium until ${fmtDate(exp)}.`,
    });
  } catch (err) {
    await alertOwner(env, `stars_error${charge}`,
      `A Stars payment from user ${uid} (${sp.total_amount} Stars, charge ID ${charge}) was received but I hit an error activating Premium. Please use /grant ${uid} <plan>. Error: ${String(err).slice(0, 200)}`);
  }
}

// ---------- /skipads and the payments settings ----------
export async function sendSkipAds(env, chatId, userId) {
  if (!runtime.appOrigin) {
    await tg(env, "sendMessage", { chat_id: chatId, text: "Premium isn't available yet. Please try again later." });
    return;
  }
  const until = await getSubExpiry(env, userId);
  const plans = Object.values(PLANS).map((p) => `• ${p.name}: ₹${p.price}`).join("\n");
  const text = until
    ? `⭐ <b>Premium is active</b> until ${fmtDate(until)}.\n\nYou can add more time any time:\n${plans}`
    : `⭐ <b>Skip the ads</b>\n\nGet your files instantly, with no verification step.\n\n${plans}`;
  await tg(env, "sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: [[{ text: "⭐ Choose a plan", web_app: { url: `${runtime.appOrigin}/app` } }]] },
  });
}
