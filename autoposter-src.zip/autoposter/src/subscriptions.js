// src/subscriptions.js - Premium subscriptions (skip ads)

import { PLANS, STAR_DEFAULTS } from "./config.js";
import { getSetting } from "./db.js";

export async function getStarPrices(env) {
  const out = {};
  for (const key of Object.keys(PLANS)) {
    const v = parseInt((await getSetting(env, `stars_${key}`)) || "", 10);
    out[key] = v > 0 ? v : STAR_DEFAULTS[key];
  }
  return out;
}

export async function starsEnabled(env) {
  return (await getSetting(env, "stars_off")) !== "1";
}

export async function getSubExpiry(env, userId) {
  const r = await env.DB.prepare("SELECT expires_at FROM subscriptions WHERE user_id = ?").bind(String(userId)).first();
  return r && r.expires_at > Date.now() ? r.expires_at : 0;
}

export async function hasActiveSub(env, userId) {
  return (await getSubExpiry(env, userId)) > 0;
}

export async function activateSubscription(env, userId, planKey) {
  const cur = await env.DB.prepare("SELECT expires_at FROM subscriptions WHERE user_id = ?").bind(String(userId)).first();
  const start = Math.max(Date.now(), cur ? cur.expires_at : 0);
  const expires = start + PLANS[planKey].days * 86400000;
  await env.DB.prepare("INSERT OR REPLACE INTO subscriptions (user_id, expires_at, plan) VALUES (?, ?, ?)")
    .bind(String(userId), expires, planKey).run();
  return expires;
}
