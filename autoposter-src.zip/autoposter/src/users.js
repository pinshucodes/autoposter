// src/users.js - User records and rate limiting

import { alertOwner } from "./alerts.js";
import { tg } from "./telegram.js";
import { RATE_MAX, RATE_WINDOW_MS, dayString } from "./utils.js";

export async function recordUser(env, from) {
  const r = await env.DB.prepare(
    "INSERT INTO users (user_id, first_name, joined_day, last_seen, active) VALUES (?, ?, ?, ?, 1) " +
    "ON CONFLICT(user_id) DO UPDATE SET first_name = excluded.first_name, last_seen = excluded.last_seen, active = 1 " +
    "RETURNING banned"
  ).bind(String(from.id), from.first_name || "", dayString(0), Date.now()).first();
  return !!(r && r.banned);
}

// ---------- Rate limit ----------
export async function isRateLimited(env, userId, chatId) {
  const now = Date.now();
  const r = await env.DB.prepare("SELECT window_start, count FROM rate WHERE user_id = ?").bind(String(userId)).first();
  if (!r || now - r.window_start > RATE_WINDOW_MS) {
    await env.DB.prepare("INSERT OR REPLACE INTO rate (user_id, window_start, count) VALUES (?, ?, 1)")
      .bind(String(userId), now).run();
    return false;
  }
  const count = r.count + 1;
  await env.DB.prepare("UPDATE rate SET count = ? WHERE user_id = ?").bind(count, String(userId)).run();
  if (count === RATE_MAX + 1) {
    await tg(env, "sendMessage", { chat_id: chatId, text: "⏳ You're going too fast. Please wait a few seconds." });
    await alertOwner(env, `rl${userId}`, `User ${userId} is sending requests very fast. To block them: /ban ${userId}`);
  }
  return count > RATE_MAX;
}
