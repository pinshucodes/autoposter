// src/telegram.js - Talking to the Telegram Bot API

// ---------- Talking to Telegram ----------
export async function tg(env, method, data, retried) {
  let json;
  try {
    const res = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    json = await res.json();
  } catch (err) {
    const text = String(err).split(env.BOT_TOKEN).join("***");
    return { ok: false, error_code: 0, description: text };
  }
  if (!json.ok && json.error_code === 429 && !retried) {
    const wait = (json.parameters && json.parameters.retry_after) || 1;
    if (wait <= 2) {
      await new Promise((r) => setTimeout(r, wait * 1000 + 100));
      return tg(env, method, data, true);
    }
  }
  return json;
}
