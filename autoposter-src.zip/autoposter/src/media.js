// src/media.js - TMDb + OMDb lookup and the channel post caption and buttons

import { getSetting } from "./db.js";
import { makeDeepLink, shortenUrl, shortlinkReady } from "./shortlink.js";
import { esc, sortQualities } from "./utils.js";

// ---------- Fetch TMDb & OMDb (IMDb) Metadata ----------
export async function fetchMediaMeta(env, info) {
  const metaOn = (await getSetting(env, "meta_enabled")) === "1";
  if (!metaOn) return null;

  const tmdbKey = await getSetting(env, "tmdb_key");
  const omdbKey = await getSetting(env, "omdb_key");
  const out = {
    title: info.cleanTitle,
    year: info.year || "",
    rating: "",
    genres: "",
    plot: "",
    poster: "",
    type: info.isSeries ? "TV Series" : "Movie",
  };

  if (tmdbKey) {
    try {
      const endpoint = info.isSeries ? "tv" : "movie";
      const yParam = info.year
        ? (info.isSeries ? `&first_air_date_year=${info.year}` : `&year=${info.year}`)
        : "";
      const url = `https://api.themoviedb.org/3/search/${endpoint}?api_key=${encodeURIComponent(tmdbKey)}&query=${encodeURIComponent(info.cleanTitle)}${yParam}`;
      const res = await fetch(url);
      const data = await res.json();
      const hit = data.results && data.results[0];
      if (hit) {
        out.title = hit.title || hit.name || out.title;
        const dateStr = hit.release_date || hit.first_air_date || "";
        if (dateStr) out.year = dateStr.slice(0, 4);
        if (hit.vote_average) out.rating = `${Number(hit.vote_average).toFixed(1)}/10`;
        if (hit.overview) out.plot = hit.overview.slice(0, 240) + (hit.overview.length > 240 ? "..." : "");
        if (hit.backdrop_path || hit.poster_path) {
          out.poster = `https://image.tmdb.org/t/p/w780${hit.poster_path || hit.backdrop_path}`;
        }
      }
    } catch (err) {
      console.log("TMDb lookup error:", err);
    }
  }

  if (omdbKey) {
    try {
      const oType = info.isSeries ? "series" : "movie";
      const yParam = info.year ? `&y=${info.year}` : "";
      const url = `https://www.omdbapi.com/?apikey=${encodeURIComponent(omdbKey)}&t=${encodeURIComponent(info.cleanTitle)}&type=${oType}${yParam}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data && data.Response === "True") {
        out.title = data.Title || out.title;
        if (data.Year && !out.year) out.year = data.Year.slice(0, 4);
        if (data.imdbRating && data.imdbRating !== "N/A") out.rating = `${data.imdbRating}/10`;
        if (data.Genre && data.Genre !== "N/A") out.genres = data.Genre;
        if (!out.plot && data.Plot && data.Plot !== "N/A") out.plot = data.Plot.slice(0, 240);
        if (!out.poster && data.Poster && data.Poster.startsWith("http")) out.poster = data.Poster;
      }
    } catch (err) {
      console.log("OMDb lookup error:", err);
    }
  }

  return out;
}

export async function buildChannelPostView(env, meta, info, items, showMediaInfo, sampleRowId, batchId) {
  const titleText = (meta && meta.title) ? meta.title : info.cleanTitle;
  const yearText = (meta && meta.year) || info.year;
  const headerTitle = yearText ? `${titleText} (${yearText})` : titleText;
  const sTag = info.isSeries ? ` — Season ${String(info.season || 1).padStart(2, "0")}` : "";

  const lines = [
    `🎬 <b>${esc(headerTitle)}${esc(sTag)}</b>`,
  ];

  if (meta) {
    const badges = [];
    if (meta.rating) badges.push(`⭐ <b>IMDb:</b> ${esc(meta.rating)}`);
    if (meta.type) badges.push(`📺 <b>Type:</b> ${esc(meta.type)}`);
    if (badges.length) lines.push(badges.join("  |  "));
    if (meta.genres) lines.push(`🎭 <b>Genre:</b> ${esc(meta.genres)}`);
  }

  const allLangs = [];
  const allQuals = [];
  const allCodecs = [];
  for (const it of items) {
    if (it.quality && !allQuals.includes(it.quality)) allQuals.push(it.quality);
    for (const l of it.audioLangs || []) {
      if (!allLangs.includes(l)) allLangs.push(l);
    }
    const cStr = [it.source, it.vCodec, it.aCodec].filter(Boolean).join(" ");
    if (cStr && !allCodecs.includes(cStr)) allCodecs.push(cStr);
  }
  allQuals.sort(sortQualities);

  if (showMediaInfo) {
    if (allLangs.length) lines.push(`🔊 <b>Audio:</b> ${esc(allLangs.join(", "))}`);
    if (allQuals.length) lines.push(`💿 <b>Qualities:</b> ${esc(allQuals.join(" | "))}`);
    if (allCodecs.length) lines.push(`⚙️ <b>Format:</b> ${esc(allCodecs[0])}`);
    if (items.length) lines.push(`📂 <b>Total Files:</b> ${items.length}`);
  }

  if (meta && meta.plot) {
    lines.push(`\n📝 <i>${esc(meta.plot)}</i>`);
  }

  lines.push("");
  lines.push(`⬇️ <b>Tap below to view all files & download:</b>`);

  const buttons = [];

  // 1. Sample Button
  const sampleChannelUrl = await getSetting(env, "sample_url");
  if (sampleChannelUrl) {
    buttons.push([{ text: "🎬 Watch Sample Video", url: sampleChannelUrl }]);
  } else if (sampleRowId) {
    const sampleLink = await makeDeepLink(env, `f${sampleRowId}`);
    buttons.push([{ text: "🎬 Watch Sample Video", url: sampleLink }]);
  }

  // 2. Download Button
    if (batchId) {
      const dLink = await makeDeepLink(env, `b${batchId}`);
      const countLabel = items.length > 1 ? ` (${items.length} Files)` : "";
      
      // Automatically shorten the deep link into your shortxlinks.in URL!
      const shortDl = (await shortlinkReady(env)) ? await shortenUrl(env, dLink) : null;
      const finalDl = shortDl || dLink;

      buttons.push([{ text: `📥 Download Now${countLabel}`, url: finalDl }]);
    }

  // 3. How to Download Button (from your tutorial_url setting)
  const tutorialUrl = await getSetting(env, "tutorial_url");
  if (tutorialUrl) {
    buttons.push([{ text: "❓ How to Download", url: tutorialUrl }]);
  }

  return { caption: lines.join("\n"), buttons };
}
