// src/cron.js - Scheduled job (runs every minute)

import { alertOwner } from "./alerts.js";
import { processBroadcast } from "./broadcast.js";
import { getChannels, getSetting, setSetting } from "./db.js";
import { runDeletions } from "./delivery.js";
import { checkAndRunScheduledDigest } from "./digest.js";
import { makeDeepLink } from "./shortlink.js";
import { tg } from "./telegram.js";

export async function runCron(env) {
  try {
    await setSetting(env, "last_cron", String(Date.now()));
    const job = await env.DB.prepare("SELECT 1 AS x FROM broadcasts WHERE status = 'running' LIMIT 1").first();
    await runDeletions(env, job ? 15 : 40);
    if (job) await processBroadcast(env, 30);

    // Automatically posts the Daily Digest at 7:00 PM IST
    await checkAndRunScheduledDigest(env, { tg, getChannels, getSetting, setSetting, makeDeepLink });
  } catch (err) {
    console.log("Cron error:", err);
    await alertOwner(env, "cron", `The scheduled cleanup job hit an error: ${String(err).slice(0, 300)}`);
  }
}
