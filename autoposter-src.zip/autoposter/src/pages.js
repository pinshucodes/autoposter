// src/pages.js - HTML pages for the two Mini Apps (verification and Skip Ads)


// ---------- Anti-Bypass Verification Mini App Page ----------
export const VERIFY_HTML = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Secure Verification</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--bg:var(--tg-theme-bg-color,#0f172a);--text:var(--tg-theme-text-color,#f8fafc);--hint:var(--tg-theme-hint-color,#94a3b8);--accent:var(--tg-theme-button-color,#2563eb);--accent-text:var(--tg-theme-button-text-color,#fff);--card:var(--tg-theme-secondary-bg-color,#1e293b)}
*{box-sizing:border-box;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
body{margin:0;padding:24px 18px;background:var(--bg);color:var(--text);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;text-align:center;display:flex;flex-direction:column;justify-content:center;min-height:92vh}
.card{background:var(--card);border-radius:18px;padding:24px 18px;box-shadow:0 8px 24px rgba(0,0,0,0.25)}
.icon{font-size:44px;margin-bottom:8px}
h1{font-size:20px;margin:6px 0}
p{color:var(--hint);font-size:14px;margin:8px 0 20px}
.btn{display:block;width:100%;padding:14px;border:0;border-radius:12px;background:var(--accent);color:var(--accent-text);font:inherit;font-weight:600;cursor:pointer}
.btn:disabled{opacity:0.6}
.err{color:#ef4444;font-size:14px;margin-top:12px}
</style></head>
<body oncontextmenu="return false;">
<div class="card" id="box">
  <div class="icon">🛡️</div>
  <h1 id="title">Preparing Secure Verification...</h1>
  <p id="desc">Please wait a moment while we generate your one-time verification session.</p>
  <button class="btn" id="go" style="display:none">🚀 Continue to Verification</button>
  <div class="err" id="err"></div>
</div>
<script>
var tg = window.Telegram && window.Telegram.WebApp;
if (tg) { tg.ready(); tg.expand(); }
var params = new URLSearchParams(location.search);
var token = params.get("t") || "";
var titleEl = document.getElementById("title");
var descEl = document.getElementById("desc");
var btnEl = document.getElementById("go");
var errEl = document.getElementById("err");

function launchShortlink(rawUrl) {
  var u = String(rawUrl || "").trim();
  if (!/^https?:\\/\\//i.test(u)) u = "https://" + u.replace(/^\\/+/, "");
  if (tg && typeof tg.openLink === "function") {
    tg.openLink(u, { try_instant_view: false });
    setTimeout(function() { try { tg.close(); } catch (e) {} }, 350);
  } else {
    window.open(u, "_blank", "noopener,noreferrer");
  }
}

if (!tg || !tg.initData) {
  titleEl.textContent = "🚫 Access Denied";
  descEl.textContent = "This verification link can only be opened directly inside the official Telegram app. External browsers and bypass tools are blocked.";
} else {
  fetch("/api/verify-link", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Init-Data": tg.initData },
    body: JSON.stringify({ token: token })
  }).then(function(r) { return r.json(); }).then(function(d) {
    if (d.error || !d.url) {
      titleEl.textContent = "⚠️ Session Expired";
      descEl.textContent = d.error || "Please return to the bot and tap the button again.";
      return;
    }
    titleEl.textContent = "🛡️ Security Check Ready";
    descEl.textContent = "Tap the button below and complete the short step to unlock your file automatically.";
    btnEl.style.display = "block";
    btnEl.onclick = function() {
      btnEl.disabled = true;
      launchShortlink(d.url);
    };
  }).catch(function() {
    errEl.textContent = "Network error. Please close and try again.";
  });
}
</script></body></html>`;

// ---------- The Mini App page (Skip Ads / Premium) ----------
export const APP_HTML = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Skip Ads</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--bg:var(--tg-theme-bg-color,#fff);--text:var(--tg-theme-text-color,#111);--hint:var(--tg-theme-hint-color,#707579);--accent:var(--tg-theme-button-color,#2481cc);--accent-text:var(--tg-theme-button-text-color,#fff);--card:var(--tg-theme-secondary-bg-color,#f1f3f5)}
*{box-sizing:border-box}
body{margin:0;padding:16px 16px calc(28px + env(safe-area-inset-bottom,0px));background:var(--bg);color:var(--text);font:16px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
h1{font-size:22px;margin:4px 0}
.sub{color:var(--hint);margin:4px 0 14px;font-size:15px}
.card{background:var(--card);border-radius:14px;padding:14px;margin-bottom:12px}
.plan{display:flex;justify-content:space-between;align-items:center;width:100%;border:0;color:var(--text);font:inherit;text-align:left;cursor:pointer}
.plan b{font-size:18px}
.btn{display:block;width:100%;padding:13px;border:0;border-radius:12px;background:var(--accent);color:var(--accent-text);font:inherit;font-weight:600;text-align:center;text-decoration:none;cursor:pointer;margin-top:10px}
.btn.ghost{background:transparent;color:var(--accent);border:1px solid var(--accent)}
.big{font-size:30px;font-weight:700;margin:2px 0}
.mono{font-family:ui-monospace,Menlo,monospace;word-break:break-all}
input{width:100%;padding:13px;border-radius:12px;border:1px solid var(--hint);background:var(--bg);color:var(--text);font:inherit;font-size:18px;letter-spacing:1px}
.err{color:#d93025;margin-top:8px;min-height:20px;font-size:14px}
ol{padding-left:20px;margin:6px 0 12px;color:var(--hint);font-size:15px}
</style></head>
<body><div id="root"></div>
<script>
var tg = window.Telegram && window.Telegram.WebApp;
if (tg) { tg.ready(); tg.expand(); }
var root = document.getElementById("root");
var ME = null;

function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
function clear() { while (root.firstChild) root.removeChild(root.firstChild); }
function api(path, body) {
  return fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Init-Data": tg ? tg.initData : "" },
    body: JSON.stringify(body || {})
  }).then(function (r) { return r.json(); })
    .catch(function () { return { error: "Network problem. Please try again." }; });
}
function fail(text) {
  clear();
  root.appendChild(el("h1", null, "Something went wrong"));
  root.appendChild(el("p", "sub", text === "auth" ? "Please open this page from the bot's /skipads button." : text));
  var b = el("button", "btn", "Try again");
  b.onclick = load;
  root.appendChild(b);
}
function load() {
  clear();
  root.appendChild(el("p", "sub", "Loading..."));
  api("/api/me").then(function (me) {
    if (me.error) return fail(me.error);
    ME = me;
    home(me);
  });
}
function home(me) {
  clear();
  root.appendChild(el("h1", null, "\\u2B50 Skip the ads"));
  root.appendChild(el("p", "sub", "Get your files instantly, with no verification step."));
  var st = el("div", "card");
  if (me.premium_until) {
    st.appendChild(el("b", null, "Premium active"));
    st.appendChild(el("div", "sub", "Until " + me.premium_until + ". Buying again adds time on top."));
  } else {
    st.appendChild(el("b", null, "No active plan"));
  }
  root.appendChild(st);
  if (me.waiting) {
    var w = el("div", "card");
    w.appendChild(el("b", null, "Payment waiting for approval"));
    w.appendChild(el("div", "sub", me.waiting.plan_name + " - Rs " + me.waiting.amount + ". You'll get a message in the bot as soon as it's approved."));
    var r = el("button", "btn ghost", "Refresh");
    r.onclick = load;
    w.appendChild(r);
    root.appendChild(w);
  }
  if (!me.upi_ready && !me.stars_ready) {
    root.appendChild(el("p", "sub", "Payments aren't set up yet. Please try again later."));
    return;
  }
  me.plans.forEach(function (p) {
    var b = el("button", "card plan");
    b.appendChild(el("span", null, p.name));
    b.appendChild(el("b", null, me.upi_ready ? "Rs " + p.price : "\\u2B50 " + p.stars));
    b.onclick = function () { choose(p); };
    root.appendChild(b);
  });
}
function choose(p) {
  if (ME.upi_ready && ME.stars_ready) return methods(p);
  if (ME.stars_ready) return startStars(p);
  startPay(p);
}
function methods(p) {
  clear();
  root.appendChild(el("h1", null, p.name));
  root.appendChild(el("p", "sub", "Choose how you'd like to pay."));
  var u = el("button", "btn", "Pay with UPI - Rs " + p.price);
  u.onclick = function () { startPay(p); };
  root.appendChild(u);
  var st = el("button", "btn", "Pay with Stars - \\u2B50 " + p.stars);
  st.onclick = function () { startStars(p); };
  root.appendChild(st);
  var back = el("button", "btn ghost", "Back");
  back.onclick = load;
  root.appendChild(back);
}
function startStars(p) {
  api("/api/stars", { plan: p.key }).then(function (d) {
    if (d.error) return fail(d.error);
    if (tg && tg.openInvoice) {
      tg.openInvoice(d.link, function (status) {
        if (status === "paid") return paid();
        if (status === "failed") return fail("The payment didn't go through. You were not charged.");
        load();
      });
    } else if (tg) {
      tg.openTelegramLink(d.link);
    }
  });
}
function paid() {
  clear();
  root.appendChild(el("h1", null, "Payment received!"));
  root.appendChild(el("p", "sub", "Premium turns on in a moment. You'll get a message in the bot."));
  var b = el("button", "btn", "Check my plan");
  b.onclick = load;
  root.appendChild(b);
}
function startPay(p) {
  api("/api/pay", { plan: p.key }).then(function (d) {
    if (d.error) return fail(d.error);
    pay(d);
  });
}
function pay(d) {
  clear();
  root.appendChild(el("h1", null, d.plan));
  var c = el("div", "card");
  c.appendChild(el("div", "sub", "Pay exactly"));
  c.appendChild(el("div", "big", "Rs " + d.amount));
  c.appendChild(el("div", "sub", "to this UPI ID (" + d.payee + ")"));
  c.appendChild(el("div", "mono", d.upi_id));
  var copy = el("button", "btn ghost", "Copy UPI ID");
  copy.onclick = function () {
    if (navigator.clipboard) navigator.clipboard.writeText(d.upi_id);
    copy.textContent = "Copied";
  };
  c.appendChild(copy);
  var open = el("a", "btn", "Open UPI app");
  open.href = d.link;
  c.appendChild(open);
  root.appendChild(c);

  var steps = el("ol");
  ["Pay the amount above in any UPI app.", "Find the 12-digit reference number (UTR) in your payment details.", "Enter it below and submit."].forEach(function (t) {
    steps.appendChild(el("li", null, t));
  });
  root.appendChild(steps);

  var input = el("input");
  input.type = "text";
  input.inputMode = "numeric";
  input.maxLength = 12;
  input.placeholder = "12-digit UTR number";
  root.appendChild(input);
  var err = el("div", "err");
  root.appendChild(err);
  var go = el("button", "btn", "I've paid - submit");
  go.onclick = function () {
    go.disabled = true;
    err.textContent = "";
    api("/api/utr", { id: d.id, utr: input.value }).then(function (res) {
      go.disabled = false;
      if (res.error) { err.textContent = res.error; return; }
      done();
    });
  };
  root.appendChild(go);
  var back = el("button", "btn ghost", "Back");
  back.onclick = load;
  root.appendChild(back);
}
function done() {
  clear();
  root.appendChild(el("h1", null, "Thank you!"));
  root.appendChild(el("p", "sub", "Your payment is being checked. You'll get a message in the bot as soon as Premium is active."));
  var b = el("button", "btn", "Close");
  b.onclick = function () { if (tg) tg.close(); else load(); };
  root.appendChild(b);
}
load();
</script></body></html>`;
