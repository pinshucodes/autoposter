// Autoposter Bot - Movie & Series Season Batching + Anti-Bypass Shortlink Shield + IMDb/TMDb/MediaInfo
// Runs on Cloudflare Workers + D1 database.
//
// Secrets (Settings > Variables and Secrets): BOT_TOKEN, OWNER_ID, WEBHOOK_SECRET
// Database binding: DB (set in wrangler.toml)
//
// This file is only the front door: it routes web requests and the cron trigger.
// All the real work lives in the other files in src/ (see README.md).

import { handleButton } from "./buttons.js";
import { runtime } from "./config.js";
import { runCron } from "./cron.js";
import { handleMessage } from "./messages.js";
import { handleApi } from "./miniapp.js";
import { APP_HTML, VERIFY_HTML } from "./pages.js";
import { handlePreCheckout } from "./payments.js";
import { handleChannelPost } from "./posts.js";
import { getBotUsername } from "./shortlink.js";
import { safeEqual } from "./utils.js";

// ---------- Cloudflare Worker Entrypoint ----------
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    runtime.appOrigin = url.origin;

    // 1. Anti-Bypass Verification Mini App Page
    if (request.method === "GET" && url.pathname === "/verify") {
      return new Response(VERIFY_HTML, {
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-store",
        },
      });
    }

    // 2. Skip-Ads / Premium Mini App Page
    if (request.method === "GET" && url.pathname === "/app") {
      return new Response(APP_HTML, {
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-store",
        },
      });
    }

    // 3. Worker Redirect Shield for Channel Buttons (/get/f12 or /get/b5)
    if (request.method === "GET" && url.pathname.startsWith("/get/")) {
      const startParam = url.pathname.slice(5).replace(/[^A-Za-z0-9_-]/g, "");
      const username = await getBotUsername(env);
      if (!username || !startParam) return new Response("Not found", { status: 404 });
      return Response.redirect(`https://t.me/${username}?start=${startParam}`, 302);
    }

    // 4. Mini App JSON APIs (/api/verify-link, /api/me, /api/pay, /api/stars, /api/utr)
    if (url.pathname.startsWith("/api/")) {
      return handleApi(request, env, url.pathname);
    }

    // 5. Telegram Webhook Endpoint
    if (request.method === "POST") {
      const secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token") || "";
      if (env.WEBHOOK_SECRET && !safeEqual(secret, env.WEBHOOK_SECRET)) {
        return new Response("Forbidden", { status: 403 });
      }
      try {
        const update = await request.json();
        if (update.pre_checkout_query) {
          await handlePreCheckout(update.pre_checkout_query, env);
        } else if (update.message) {
          await handleMessage(update.message, env);
        } else if (update.channel_post) {
          await handleChannelPost(update.channel_post, env);
        } else if (update.callback_query) {
          await handleButton(update.callback_query, env);
        }
      } catch (err) {
        console.log("Webhook error:", String(err).split(env.BOT_TOKEN).join("***"));
      }
      return new Response("OK");
    }

    return new Response("OK");
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(runCron(env));
  },
};
