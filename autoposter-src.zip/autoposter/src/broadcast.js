// src/broadcast.js - /post channel picker and the broadcast engine

import { clearState, setState } from "./db.js";
import { tg } from "./telegram.js";

export async function getPostTargets(env) {
  const r = await env.DB.prepare(
    "SELECT chat_id, title, GROUP_CONCAT(role) AS roles FROM channels GROUP BY chat_id ORDER BY title, chat_id"
  ).all();
  return (r.results || []).slice(0, 30);
}

export async function countBroadcastUsers(env) {
  const r = await env.DB.prepare("SELECT COUNT(*) AS n FROM users WHERE banned = 0 AND active = 1").first();
  return r ? r.n : 0;
}

export function renderPicker(targets, mask, note) {
  let text = "📣 <b>Choose where to post</b>\n\nTap a channel to switch it on or off, then tap Send.";
  if (note) text += `\n\n${note}`;
  const buttons = targets.map((c, i) => [{
    text: `${mask & (1 << i) ? "✅" : "⬜"} ${c.title}`.slice(0, 60),
    callback_data: `pk:t:${i}`,
  }]);
  buttons.push([
    { text: "📤 Send", callback_data: "pk:go" },
    { text: "✖️ Cancel", callback_data: "pk:no" },
  ]);
  return { text, buttons };
}

export async function askConfirm(env, msg, kind) {
  const userId = String(msg.from.id);
  await clearState(env, userId);

  if (kind === "post") {
    const targets = await getPostTargets(env);
    if (!targets.length) {
      await tg(env, "sendMessage", {
        chat_id: msg.chat.id,
        text: "You haven't added any channels yet. Add them in /settings first.",
      });
      return;
    }
    let mask = 0;
    targets.forEach((c, i) => { if (c.roles !== "source") mask |= 1 << i; });
    await setState(env, userId, `pick:${msg.message_id}:${mask}`);
    const view = renderPicker(targets, mask);
    await tg(env, "sendMessage", {
      chat_id: msg.chat.id,
      text: view.text,
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: view.buttons },
    });
    return;
  }

  await tg(env, "sendMessage", {
    chat_id: msg.chat.id,
    text: `📢 Send this message to <b>${await countBroadcastUsers(env)}</b> users?`,
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [[
        { text: "✅ Yes, send", callback_data: `pst:broadcast:${msg.message_id}` },
        { text: "✖️ Cancel", callback_data: "pst:no" },
      ]],
    },
  });
}

export async function processBroadcast(env, limit) {
  const job = await env.DB.prepare("SELECT * FROM broadcasts WHERE status = 'running' ORDER BY id LIMIT 1").first();
  if (!job) return;

  const now = Date.now();
  const lock = await env.DB.prepare(
    "UPDATE broadcasts SET locked_until = ? WHERE id = ? AND locked_until < ? AND status = 'running'"
  ).bind(now + 55000, job.id, now).run();
  if (!lock.meta.changes) return;

  const users = await env.DB.prepare(
    "SELECT rowid AS rid, user_id FROM users WHERE rowid > ? AND banned = 0 AND active = 1 ORDER BY rowid LIMIT ?"
  ).bind(job.last_rowid, limit).all();
  const list = users.results || [];

  let sent = 0, failed = 0, last = job.last_rowid, backoff = 0;
  for (const u of list) {
    const r = await tg(env, "copyMessage", {
      chat_id: u.user_id, from_chat_id: job.from_chat, message_id: job.message_id,
    });
    if (!r.ok && r.error_code === 429) {
      backoff = ((r.parameters && r.parameters.retry_after) || 5) * 1000;
      break;
    }
    if (r.ok) {
      sent++;
    } else {
      failed++;
      if (r.error_code === 403) {
        await env.DB.prepare("UPDATE users SET active = 0 WHERE user_id = ?").bind(u.user_id).run();
      }
    }
    last = u.rid;
  }

  const finished = !backoff && list.length < limit;
  await env.DB.prepare(
    "UPDATE broadcasts SET last_rowid = ?, sent = sent + ?, failed = failed + ?, locked_until = ?, " +
    "status = CASE WHEN status = 'running' AND ? = 1 THEN 'done' ELSE status END WHERE id = ?"
  ).bind(last, sent, failed, backoff ? Date.now() + backoff : 0, finished ? 1 : 0, job.id).run();

  if (finished) {
    const after = await env.DB.prepare("SELECT status FROM broadcasts WHERE id = ?").bind(job.id).first();
    if (after && after.status === "done") {
      await tg(env, "sendMessage", {
        chat_id: job.owner_chat,
        text: `✅ Broadcast finished.\nDelivered: ${job.sent + sent}\nFailed: ${job.failed + failed}`,
      });
    }
  }
}
