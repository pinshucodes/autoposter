// src/buttons.js - Inline button taps

import { countBroadcastUsers, getPostTargets, processBroadcast, renderPicker } from "./broadcast.js";
import { PLANS, ROLES } from "./config.js";
import { clearState, getBatchRow, getFileRow, getSetting, getState, removeChannel, setSetting, setState } from "./db.js";
import { deliverBatch, deliverFile, getMissingChannels, sendBatchMenuToUser, sendFileToUser } from "./delivery.js";
import { buildMetaMenu, buildPayMenu, showCoverMenu, showDeleteMenu, showMainMenu, showRoleMenu, showShortlinkMenu } from "./menus.js";
import { activateSubscription, starsEnabled } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { isRateLimited } from "./users.js";
import { esc, fmtDate, formatDelay } from "./utils.js";

// ---------- Handling button taps ----------
export async function handleButton(query, env) {
  if (!query.message || !query.data) {
    await tg(env, "answerCallbackQuery", { callback_query_id: query.id });
    return;
  }
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const userId = String(query.from.id);
  const parts = query.data.split(":");
  const action = parts[0];

  // User tapped a File button, NEXT/PREVIOUS page, or Send All inside the DM File Menu
  if (action === "bep" || action === "ball" || action === "bpage") {
    if (userId !== String(env.OWNER_ID)) {
      const b = await env.DB.prepare("SELECT banned FROM users WHERE user_id = ?").bind(userId).first();
      if ((b && b.banned) || (await isRateLimited(env, userId, chatId))) {
        await tg(env, "answerCallbackQuery", { callback_query_id: query.id });
        return;
      }
    }
    if (action === "bpage") {
      const batch = await getBatchRow(env, Number(parts[1]));
      if (!batch) {
        await tg(env, "answerCallbackQuery", { callback_query_id: query.id, text: "Menu expired.", show_alert: true });
        return;
      }
      await tg(env, "answerCallbackQuery", { callback_query_id: query.id });
      await sendBatchMenuToUser(env, chatId, batch, Number(parts[2]) || 0, messageId);
      return;
    }
    if (action === "bep") {
      const row = await getFileRow(env, Number(parts[1]));
      if (!row) {
        await tg(env, "answerCallbackQuery", { callback_query_id: query.id, text: "Episode no longer available.", show_alert: true });
        return;
      }
      await tg(env, "answerCallbackQuery", { callback_query_id: query.id, text: "Sending episode..." });
      await sendFileToUser(env, chatId, row, false);
      return;
    }
    if (action === "ball") {
      const batch = await getBatchRow(env, Number(parts[1]));
      if (!batch) {
        await tg(env, "answerCallbackQuery", { callback_query_id: query.id, text: "Batch no longer available.", show_alert: true });
        return;
      }
      let items = [];
      try { items = JSON.parse(batch.items_json || "[]"); } catch (e) { items = []; }
      items.sort((a, b) => (a.season || 1) - (b.season || 1) || (a.episode || 0) - (b.episode || 0));
      await tg(env, "answerCallbackQuery", { callback_query_id: query.id, text: `Sending ${items.length} episodes...` });
      for (const ep of items) {
        const row = await getFileRow(env, ep.rowId);
        if (row) await sendFileToUser(env, chatId, row, true);
      }
      const rawMins = await getSetting(env, "delete_minutes");
      const mins = rawMins === null ? 5 : parseInt(rawMins, 10);
      if (mins) {
        const notice = await tg(env, "sendMessage", {
          chat_id: chatId,
          text: `⏳ <b>Auto-Delete Notice:</b> All episodes above will be deleted in <b>${formatDelay(mins)}</b>. Forward or share them to your Saved Messages now!`,
          parse_mode: "HTML",
        });
        if (notice.ok) {
          await env.DB.prepare("INSERT INTO deletions (chat_id, message_id, delete_at) VALUES (?, ?, ?)")
            .bind(String(chatId), notice.result.message_id, Date.now() + mins * 60 * 1000).run();
        }
      }
      return;
    }
  }

  // ForceSub "I've Joined" check for Single File (chk) or Series Season Batch (chkb)
  if (action === "chk" || action === "chkb") {
    if (userId !== String(env.OWNER_ID)) {
      const b = await env.DB.prepare("SELECT banned FROM users WHERE user_id = ?").bind(userId).first();
      if ((b && b.banned) || (await isRateLimited(env, userId, chatId))) {
        await tg(env, "answerCallbackQuery", { callback_query_id: query.id });
        return;
      }
    }
    const missing = await getMissingChannels(env, query.from.id);
    if (missing.length) {
      await tg(env, "answerCallbackQuery", {
        callback_query_id: query.id, text: "You haven't joined all the channels yet.", show_alert: true,
      });
      return;
    }
    await tg(env, "answerCallbackQuery", { callback_query_id: query.id });
    await tg(env, "deleteMessage", { chat_id: chatId, message_id: messageId });

    // With the 6-hour pass OFF there is no pass to find, and the user already verified before this button appeared.
    const passOff = (await getSetting(env, "vpass_enabled")) === "0";
    if (action === "chkb") {
      const batch = await getBatchRow(env, Number(parts[1]));
      if (batch) await deliverBatch(env, chatId, query.from.id, batch, false, passOff);
    } else {
      const row = await getFileRow(env, Number(parts[1]));
      if (row) await deliverFile(env, chatId, query.from.id, row, false, passOff);
    }
    return;
  }

  if (userId !== String(env.OWNER_ID)) {
    await tg(env, "answerCallbackQuery", {
      callback_query_id: query.id,
      text: "Only the owner can do this.",
      show_alert: true,
    });
    return;
  }
  await tg(env, "answerCallbackQuery", { callback_query_id: query.id });

  if (action === "close") {
    await clearState(env, userId);
    await tg(env, "deleteMessage", { chat_id: chatId, message_id: messageId });
    return;
  }

  if (action === "back") {
    await clearState(env, userId);
    await showMainMenu(env, chatId, messageId);
    return;
  }

  if (action === "role" && ROLES[parts[1]]) {
    await clearState(env, userId);
    const page = Number.isInteger(Number(parts[2])) ? Number(parts[2]) : 0;
    await showRoleMenu(env, chatId, messageId, parts[1], page);
    return;
  }

  if (action === "add" && ROLES[parts[1]]) {
    const role = parts[1];
    await setState(env, userId, `add:${role}`);
    await tg(env, "editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text:
        `${ROLES[role].emoji} <b>${ROLES[role].name}</b>\n\n` +
        "Make me an <b>admin</b> in the channel first. Then <b>forward any message</b> from that channel here, " +
        "or send its ID (like <code>-1001234567890</code>) or @username.",
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: `role:${role}` }]] },
    });
    return;
  }

  if (action === "rm" && ROLES[parts[1]]) {
    const page = Number.isInteger(Number(parts[2])) ? Number(parts[2]) : 0;
    const targetChatId = Number.isInteger(Number(parts[2])) ? parts.slice(3).join(":") : parts.slice(2).join(":");
    await removeChannel(env, parts[1], targetChatId);
    await showRoleMenu(env, chatId, messageId, parts[1], page);
    return;
  }

  if (action === "pst") {
    const edit = (text) => tg(env, "editMessageText", {
      chat_id: chatId, message_id: messageId, text, parse_mode: "HTML",
    });
    if (parts[1] === "no") {
      await edit("Cancelled.");
      return;
    }
    if (parts[1] === "broadcast") {
      const srcMsg = Number(parts[2]);
      const running = await env.DB.prepare("SELECT 1 AS x FROM broadcasts WHERE status = 'running' LIMIT 1").first();
      if (running) {
        await edit("⚠️ A broadcast is already running. Please wait for it to finish, or send /stopbroadcast.");
        return;
      }
      const total = await countBroadcastUsers(env);
      await env.DB.prepare(
        "INSERT INTO broadcasts (from_chat, message_id, owner_chat, total) VALUES (?, ?, ?, ?)"
      ).bind(String(chatId), srcMsg, String(chatId), total).run();
      await edit(`📢 Broadcast started for <b>${total}</b> users. I'll message you when it's finished. (/stopbroadcast cancels it.)`);
      await processBroadcast(env, 35);
    }
    return;
  }

  if (action === "pk") {
    const edit = (text, markup) => tg(env, "editMessageText", {
      chat_id: chatId, message_id: messageId, text, parse_mode: "HTML", reply_markup: markup,
    });
    if (parts[1] === "no") {
      await clearState(env, userId);
      await edit("Cancelled.");
      return;
    }
    const st = (await getState(env, userId)) || "";
    const m = st.match(/^pick:(\d+):(\d+)$/);
    if (!m) {
      await edit("This /post session has expired. Send /post again.");
      return;
    }
    const srcMsg = Number(m[1]);
    let mask = Number(m[2]);
    const targets = await getPostTargets(env);

    if (parts[1] === "t") {
      mask ^= 1 << Number(parts[2]);
      await setState(env, userId, `pick:${srcMsg}:${mask}`);
      const view = renderPicker(targets, mask);
      await edit(view.text, { inline_keyboard: view.buttons });
      return;
    }

    if (parts[1] === "go") {
      const chosen = targets.filter((c, i) => mask & (1 << i));
      if (!chosen.length) {
        const view = renderPicker(targets, mask, "⚠️ Choose at least one channel.");
        await edit(view.text, { inline_keyboard: view.buttons });
        return;
      }
      let ok = 0;
      const failed = [];
      for (const c of chosen) {
        const r = await tg(env, "copyMessage", { chat_id: c.chat_id, from_chat_id: chatId, message_id: srcMsg });
        if (r.ok) ok++; else failed.push(c.title);
      }
      await clearState(env, userId);
      let text = `✅ Posted to ${ok} of ${chosen.length} channel(s).`;
      if (failed.length) {
        text += `\n\n⚠️ Failed: ${failed.map(esc).join(", ")}\nCheck that I'm an admin there with the Post Messages permission.`;
      }
      await edit(text);
    }
    return;
  }

  if (action === "cov") {
    const sub = parts[1];
    const kind = parts[2];
    const validKind = kind === "pdf" || kind === "lecture";
    if (sub === "set" && validKind) {
      await setState(env, userId, `set:cover_${kind}`);
      await tg(env, "editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text: `🖼️ Send the photo to use as the <b>${kind === "pdf" ? "PDF" : "Video"} cover</b>.`,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: "cov:menu" }]] },
      });
      return;
    }
    if (sub === "rm" && validKind) {
      await env.DB.prepare("DELETE FROM settings WHERE key = ?").bind(`cover_${kind}`).run();
    }
    await clearState(env, userId);
    await showCoverMenu(env, chatId, messageId);
    return;
  }

  if (action === "del") {
    const sub = parts[1];
    if (sub === "custom") {
      await setState(env, userId, "set:delete_minutes");
      await tg(env, "editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text: "✏️ Send the number of minutes (1 to 2820). For example, <code>5</code> means 5 minutes.",
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: "del:menu" }]] },
      });
      return;
    }
    if (sub === "set") {
      await setSetting(env, "delete_minutes", String(parseInt(parts[2], 10) || 0));
    }
    await clearState(env, userId);
    await showDeleteMenu(env, chatId, messageId);
    return;
  }

  if (action === "pay") {
    const sub = parts[1];
    if (sub === "stars") {
      await setState(env, userId, "set:stars_prices");
      await tg(env, "editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text: "⭐ Send the 4 Star prices in this order: week, month, 2 months, year.\n\nExample: <code>12 35 58 290</code>",
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: "pay:menu" }]] },
      });
      return;
    }
    if (sub === "startoggle") {
      await setSetting(env, "stars_off", (await starsEnabled(env)) ? "1" : "0");
    }
    if (sub === "upi" || sub === "name") {
      await setState(env, userId, `set:upi_${sub === "upi" ? "id" : "name"}`);
      await tg(env, "editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text: sub === "upi"
          ? "💳 Send your UPI ID, like <code>name@bank</code>. Customers will pay to this ID."
          : "💳 Send the name to show on payments, like <code>My Channel</code>.",
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: "pay:menu" }]] },
      });
      return;
    }
    if (sub === "ok" || sub === "no") {
      const id = Number(parts[2]);
      const pay = await env.DB.prepare("SELECT * FROM payments WHERE id = ?").bind(id).first();
      const edit = (text) => tg(env, "editMessageText", { chat_id: chatId, message_id: messageId, text, parse_mode: "HTML" });
      if (!pay) { await edit("Payment not found."); return; }
      const approve = sub === "ok";
      const upd = await env.DB.prepare("UPDATE payments SET status = ?, decided = ? WHERE id = ? AND status = 'submitted'")
        .bind(approve ? "approved" : "rejected", Date.now(), id).run();
      if (!upd.meta.changes) { await edit(`This payment was already ${esc(pay.status)}.`); return; }
      const plan = PLANS[pay.plan];
      if (approve) {
        const exp = await activateSubscription(env, pay.user_id, pay.plan);
        await tg(env, "sendMessage", { chat_id: pay.user_id, text: `✅ Payment approved! Premium is active until ${fmtDate(exp)}. Enjoy ad-free downloads.` });
        await edit(`✅ Approved: user ${esc(pay.user_id)}, ${esc(plan.name)} (₹${plan.price}). Premium until ${fmtDate(exp)}.`);
      } else {
        await tg(env, "sendMessage", { chat_id: pay.user_id, text: "❌ We couldn't confirm your payment. If you paid, please contact the admin with your payment screenshot." });
        await edit(`❌ Rejected: user ${esc(pay.user_id)}, ${esc(plan.name)} (₹${plan.price}).`);
      }
      return;
    }
    await clearState(env, userId);
    const pm = await buildPayMenu(env);
    await tg(env, "editMessageText", {
      chat_id: chatId, message_id: messageId, text: pm.text, parse_mode: "HTML",
      reply_markup: { inline_keyboard: pm.buttons },
    });
    return;
  }

  // IMDb, TMDb, Multi-Quality & Shield settings
  if (action === "meta") {
    const sub = parts[1];
    if (sub === "tmdb" || sub === "omdb" || sub === "sample") {
      const fieldName = sub === "sample" ? "sample_url" : `${sub}_key`;
      await setState(env, userId, `set:${fieldName}`);
      const prompt = sub === "tmdb"
        ? "🔑 Send your <b>TMDb API Key (v3 auth)</b> from themoviedb.org.\n\nI'll delete your message right after saving it."
        : sub === "omdb"
        ? "🔑 Send your <b>OMDb API Key</b> from omdbapi.com.\n\nI'll delete your message right after saving it."
        : "🎬 Send your <b>Sample Channel Link</b> (like <code>https://t.me/yoursamplechannel</code> or <code>@yoursamplechannel</code>).\n\nThis button will appear on all Movie & Series posts.";
      await tg(env, "editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text: prompt,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: "meta:menu" }]] },
      });
      return;
    }
    let note = "";
    if (sub === "rmsample") {
      await env.DB.prepare("DELETE FROM settings WHERE key = 'sample_url'").run();
      note = "🗑 Sample channel link removed.";
    }
    if (sub === "toggle") {
      const on = (await getSetting(env, "meta_enabled")) === "1";
      if (on) {
        await setSetting(env, "meta_enabled", "0");
      } else if (!(await getSetting(env, "tmdb_key")) && !(await getSetting(env, "omdb_key"))) {
        note = "⚠️ Set at least one API key (TMDb or OMDb) first.";
      } else {
        await setSetting(env, "meta_enabled", "1");
      }
    }
    if (sub === "mitoggle") {
      const miOn = (await getSetting(env, "mediainfo_enabled")) !== "0";
      await setSetting(env, "mediainfo_enabled", miOn ? "0" : "1");
    }
    if (sub === "grouptoggle") {
      const gOn = (await getSetting(env, "group_qualities")) !== "0";
      await setSetting(env, "group_qualities", gOn ? "0" : "1");
    }
    if (sub === "shieldtoggle") {
      const sOn = (await getSetting(env, "shield_redirect")) !== "0";
      await setSetting(env, "shield_redirect", sOn ? "0" : "1");
    }
    if (sub === "prottoggle") {
      const pOn = (await getSetting(env, "protect_files")) === "1";
      await setSetting(env, "protect_files", pOn ? "0" : "1");
    }
    await clearState(env, userId);
    const mmenu = await buildMetaMenu(env, note);
    await tg(env, "editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text: mmenu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: mmenu.buttons },
    });
    return;
  }

  // Shortlink & Tutorial settings: sl:menu, sl:toggle, sl:domain, sl:key, sl:tutorial, sl:rmtut
  if (action === "sl") {
    const sub = parts[1];
    if (sub === "domain" || sub === "key" || sub === "tutorial") {
      const fieldMap = { domain: "shortlink_domain", key: "shortlink_key", tutorial: "tutorial_url" };
      await setState(env, userId, `set:${fieldMap[sub]}`);
      const prompts = {
        domain: "🌐 Send your shortlink domain (for example: <code>gplinks.in</code> or <code>shrinkme.io</code>):",
        key: "🔑 Send your shortlink API key. I'll delete your message right after saving it.",
        tutorial: "🎬 Send the link to your <b>How to Verify</b> tutorial video/post (for example: <code>https://t.me/yourchannel/10</code>):",
      };
      await tg(env, "editMessageText", {
        chat_id: chatId,
        message_id: messageId,
        text: prompts[sub],
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✖️ Cancel", callback_data: "sl:menu" }]] },
      });
      return;
    }
    let note = "";
    if (sub === "toggle_vpass") {
      const cur = (await getSetting(env, "vpass_enabled")) !== "0";
      await setSetting(env, "vpass_enabled", cur ? "0" : "1");
      note = cur ? "🔴 6-Hour Pass turned OFF (Verify every movie)." : "🟢 6-Hour Pass turned ON (Verify once per 6 hours).";
    }
    if (sub === "rmtut") {
      await env.DB.prepare("DELETE FROM settings WHERE key = 'tutorial_url'").run();
      note = "🗑️ Tutorial link removed.";
    }
    if (sub === "toggle") {
      const on = (await getSetting(env, "shortlink_enabled")) === "1";
      if (on) {
        await setSetting(env, "shortlink_enabled", "0");
      } else {
        const d = await getSetting(env, "shortlink_domain");
        const k = await getSetting(env, "shortlink_key");
        if (!d || !k) {
          note = "⚠️ Set both your Domain and API Key first.";
        } else {
          await setSetting(env, "shortlink_enabled", "1");
        }
      }
    }
    await clearState(env, userId);
    await showShortlinkMenu(env, chatId, messageId, note);
    return;
  }
}
