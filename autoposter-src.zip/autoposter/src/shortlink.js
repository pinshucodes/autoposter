// src/shortlink.js - Bot username, deep links, shortlink API and the verification message

import { runtime } from "./config.js";
import { getSetting, setSetting } from "./db.js";
import { tg } from "./telegram.js";
import { esc } from "./utils.js";

let CACHED_BOT_USERNAME = null;

export async function getBotUsername(env) {
  if (CACHED_BOT_USERNAME) return CACHED_BOT_USERNAME;
  const me = await tg(env, "getMe", {});
  if (me.ok && me.result.username) {
    CACHED_BOT_USERNAME = me.result.username;
    await setSetting(env, "bot_username", CACHED_BOT_USERNAME);
    return CACHED_BOT_USERNAME;
  }
  return (await getSetting(env, "bot_username")) || "";
}

export async function makeDeepLink(env, startParam) {
  const shieldOn = (await getSetting(env, "shield_redirect")) !== "0"; // ON by default
  if (shieldOn && runtime.appOrigin) {
    return `${runtime.appOrigin}/get/${startParam}`;
  }
  const username = await getBotUsername(env);
  return `https://t.me/${username}?start=${startParam}`;
}

// ---------- Shortlink & Anti-Bypass Verification ----------
export async function shortlinkReady(env) {
  const on = await getSetting(env, "shortlink_enabled");
  const domain = await getSetting(env, "shortlink_domain");
  const key = await getSetting(env, "shortlink_key");
  return on === "1" && !!domain && !!key;
}

export async function shortenUrl(env, longUrl) {
  const domain = await getSetting(env, "shortlink_domain");
  const key = await getSetting(env, "shortlink_key");
  if (!domain || !key) return null;
  try {
    const api = `https://${domain}/api?api=${encodeURIComponent(key)}&url=${encodeURIComponent(longUrl)}`;
    const res = await fetch(api);
    const data = await res.json();
    if (data.status === "success" && data.shortenedUrl) return data.shortenedUrl;
    console.log("Shortlink API said:", JSON.stringify(data));
  } catch (err) {
    console.log("Shortlink error:", err);
  }
  return null;
}

// Anti-Bypass Verification:
// Uses a Telegram Mini App (web_app) button so long-pressing NEVER shows a URL or "Copy" option!
// Plus adds the "How to Verify" tutorial button right below it.
// Negative file_row_id (-batchId) represents a Series Season Batch!
export async function sendVerifyLink(env, chatId, userId, targetId, displayTitle) {
  const token = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
  await env.DB.prepare("DELETE FROM tokens WHERE created < ?").bind(Date.now() - 24 * 3600 * 1000).run();
  await env.DB.prepare(
    "INSERT INTO tokens (token, user_id, file_row_id, created) VALUES (?, ?, ?, ?)"
  ).bind(token, String(userId), targetId, Date.now()).run();

  const tutorialUrl = await getSetting(env, "tutorial_url");
  const vpassOn = (await getSetting(env, "vpass_enabled")) !== "0";

  const username = await getBotUsername(env);
  const startUrl = `https://t.me/${username}?start=v${token}`;

  const keyboard = [];
  if (runtime.appOrigin) {
    // Mini App button: long-pressing it never shows a link. The shortlink is created inside the Mini App (/api/verify-link).
    keyboard.push([{ text: "🔓 Click Here to Verify", web_app: { url: `${runtime.appOrigin}/verify?t=${token}` } }]);
  } else {
    // Fallback if the worker address isn't known yet
    const short = await shortenUrl(env, startUrl);
    keyboard.push([{ text: "🔓 Click Here to Verify (Open Browser)", url: short || startUrl }]);
  }

  if (tutorialUrl) {
    keyboard.push([{ text: "🎬 How to Verify (Tutorial Video)", url: tutorialUrl }]);
  }

  const modeNote = vpassOn
    ? "⏱️ <b>1 Verification unlocks ALL movies & series for 6 Hours!</b>"
    : "🔓 <b>Complete 1 quick verification to unlock this file!</b>";

  await tg(env, "sendMessage", {
    chat_id: chatId,
    text:
      `🔐 <b>Verification Required</b>\n\n` +
      `🎬 <b>${esc(displayTitle || "Media File")}</b>\n\n` +
      `${modeNote}\n` +
      `1️⃣ Tap <b>Click Here to Verify</b> below to open your browser.\n` +
      `2️⃣ Complete the shortlink ad — it will automatically bring you back here and deliver your file!`,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: keyboard },
  });
}
