// src/alerts.js - Alerts sent to the owner

import { getSetting, setSetting } from "./db.js";
import { tg } from "./telegram.js";

// ---------- Alerts to the owner ----------
export async function alertOwner(env, key, text) {
  try {
    const last = parseInt((await getSetting(env, `alert_${key}`)) || "0", 10);
    if (Date.now() - last < 30 * 60 * 1000) return;
    await setSetting(env, `alert_${key}`, String(Date.now()));
    await tg(env, "sendMessage", { chat_id: env.OWNER_ID, text: `🚨 ${text}` });
  } catch (err) {
    console.log("Alert failed:", err);
  }
}
