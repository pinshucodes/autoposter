// src/settings.js - Owner-typed settings input and channel checking

import { PLANS } from "./config.js";
import { clearState, getSetting, setSetting } from "./db.js";
import { buildCoverMenu, buildDeleteMenu, buildMetaMenu, buildPayMenu, buildShortlinkMenu } from "./menus.js";
import { shortenUrl } from "./shortlink.js";
import { tg } from "./telegram.js";

// Owner typed a new setting value
export async function handleSettingInput(env, msg, field) {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (field.startsWith("cover_")) {
    if (!msg.photo) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: "Please send a photo (not a file), or /cancel to stop.",
      });
      return;
    }
    await setSetting(env, field, msg.photo[msg.photo.length - 1].file_id);
    await clearState(env, userId);
    const cmenu = await buildCoverMenu(env, "✅ Cover saved.");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: cmenu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: cmenu.buttons },
    });
    return;
  }

  if (field === "stars_prices") {
    const nums = (msg.text || "").trim().split(/[\s,]+/).map(Number);
    if (nums.length !== 4 || nums.some((n) => !Number.isInteger(n) || n < 1 || n > 100000)) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: "Please send 4 whole numbers in this order: week, month, 2 months, year. Example: 12 35 58 290\n\n/cancel to stop.",
      });
      return;
    }
    const keys = Object.keys(PLANS);
    for (let k = 0; k < keys.length; k++) await setSetting(env, `stars_${keys[k]}`, String(nums[k]));
    await clearState(env, userId);
    const smenu = await buildPayMenu(env, "✅ Star prices saved.");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: smenu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: smenu.buttons },
    });
    return;
  }

  if (field === "upi_id" || field === "upi_name") {
    const v = (msg.text || "").trim();
    const valid = field === "upi_id"
      ? /^[A-Za-z0-9._-]{2,64}@[A-Za-z][A-Za-z0-9]{1,30}$/.test(v)
      : v.length >= 2 && v.length <= 40 && !/[&?=#%<>]/.test(v);
    if (!valid) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: field === "upi_id"
          ? "That doesn't look like a UPI ID. It should look like name@bank. Try again, or /cancel."
          : "Please send a short name (2 to 40 letters, no special symbols), or /cancel.",
      });
      return;
    }
    await setSetting(env, field, v);
    await clearState(env, userId);
    const pmenu = await buildPayMenu(env, "✅ Saved.");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: pmenu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: pmenu.buttons },
    });
    return;
  }

  let value = (msg.text || "").trim();
  if (!value) {
    await tg(env, "sendMessage", { chat_id: chatId, text: "Please send it as text, or /cancel to stop." });
    return;
  }
  if (field === "delete_minutes") {
    const mins = parseInt(value, 10);
    if (!/^\d+$/.test(value) || mins < 1 || mins > 2820) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: "Please send a number of minutes between 1 and 2820 (that's 47 hours), or /cancel to stop.",
      });
      return;
    }
    await setSetting(env, "delete_minutes", String(mins));
    await clearState(env, userId);
    const dmenu = await buildDeleteMenu(env, "✅ Saved.");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: dmenu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: dmenu.buttons },
    });
    return;
  }
  if (field === "tmdb_key" || field === "omdb_key") {
    await tg(env, "deleteMessage", { chat_id: chatId, message_id: msg.message_id });
    await setSetting(env, field, value);
    await setSetting(env, "meta_enabled", "1");
    await clearState(env, userId);
    const mmenu = await buildMetaMenu(env, "✅ API key saved & IMDb/TMDb enabled!");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: mmenu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: mmenu.buttons },
    });
    return;
  }
  if (field === "tutorial_url" || field === "sample_url") {
    if (!/^https?:\/\/\S+/i.test(value) && !/^@\w+$/i.test(value)) {
      await tg(env, "sendMessage", {
        chat_id: chatId,
        text: "Please send a valid channel link starting with https:// (like https://t.me/yourchannel) or @username, or /cancel.",
      });
      return;
    }
    if (value.startsWith("@")) value = `https://t.me/${value.slice(1)}`;
    await setSetting(env, field, value);
    await clearState(env, userId);
    const menu = field === "sample_url"
      ? await buildMetaMenu(env, "✅ Sample channel link saved!")
      : await buildShortlinkMenu(env, "✅ Tutorial link saved!");
    await tg(env, "sendMessage", {
      chat_id: chatId,
      text: menu.text,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: menu.buttons },
    });
    return;
  }
  if (field === "shortlink_domain") {
    value = value.replace(/^https?:\/\//i, "").replace(/\/.*$/, "").toLowerCase();
  }
  if (field === "shortlink_key") {
    await tg(env, "deleteMessage", { chat_id: chatId, message_id: msg.message_id });
  }
  await setSetting(env, field, value);
  await clearState(env, userId);

  let note = "✅ Saved.";
  const domain = await getSetting(env, "shortlink_domain");
  const key = await getSetting(env, "shortlink_key");
  if (domain && key) {
    const test = await shortenUrl(env, "https://t.me/telegram");
    note += test ? " Test shortlink worked ✅" : " ⚠️ Test failed. Double-check your domain and API key.";
  }
  const menu = await buildShortlinkMenu(env, note);
  await tg(env, "sendMessage", {
    chat_id: chatId,
    text: menu.text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: menu.buttons },
  });
}

// ---------- Checking a channel ----------
export function extractChannelRef(msg) {
  const fo = msg.forward_origin;
  if (fo && fo.type === "channel") return fo.chat.id;
  if (fo && fo.type === "chat" && fo.sender_chat) return fo.sender_chat.id;
  if (msg.forward_from_chat) return msg.forward_from_chat.id;
  const t = (msg.text || "").trim();
  if (/^-100\d+$/.test(t)) return t;
  if (/^@\w+$/.test(t)) return t;
  return null;
}

export async function checkChannel(env, ref, role) {
  const chat = await tg(env, "getChat", { chat_id: ref });
  if (!chat.ok) return { error: "I can't find that channel. Check the ID and make sure I'm added as an admin." };
  const isGroup = chat.result.type === "supergroup" || chat.result.type === "group";
  if (chat.result.type !== "channel" && !(role === "source" && isGroup)) {
    return { error: role === "source" ? "That's not a channel or group." : "That's not a channel. Please send a channel." };
  }

  const me = await tg(env, "getMe", {});
  const member = await tg(env, "getChatMember", { chat_id: chat.result.id, user_id: me.result.id });
  if (!member.ok || member.result.status !== "administrator") {
    return { error: "Please add me as an <b>admin</b> in that channel first, then send it again." };
  }
  if ((role === "lectures" || role === "pdfs") && member.result.can_post_messages === false) {
    return { error: "I'm an admin there, but I need the <b>Post Messages</b> permission. Turn it on and send again." };
  }
  if (role === "forcesub") {
    let link = chat.result.username ? `https://t.me/${chat.result.username}` : null;
    if (!link) {
      const inv = await tg(env, "exportChatInviteLink", { chat_id: chat.result.id });
      if (inv.ok) link = inv.result;
    }
    if (!link) {
      return { error: "I couldn't get a join link. Give me the <b>Invite Users via Link</b> permission in that channel and send again." };
    }
    return { id: chat.result.id, title: chat.result.title, link };
  }
  return { id: chat.result.id, title: chat.result.title };
}
