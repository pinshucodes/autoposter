// src/digest.js - Daily 7:00 PM IST Upload Digest for ForceSub Channels

import { esc, sortQualities } from "./utils.js";
import { resolveTargetChannels } from "./testmode.js";

// Telegram allows 4096 characters per message and 1024 per photo caption.
const MAX_MESSAGE_LEN = 3900;
const MAX_CAPTION_LEN = 1024;

// Splits the digest over several messages so a busy day never goes over Telegram's size limit.
function paginate(header, entries, footer, limit) {
  const pages = [];
  let cur = header;
  for (const entry of entries) {
    if (cur && cur.length + 1 + entry.length > limit) {
      pages.push(cur);
      cur = entry;
    } else {
      cur = cur ? `${cur}\n${entry}` : entry;
    }
  }
  if (cur.length + 1 + footer.length > limit) {
    pages.push(cur);
    cur = footer;
  } else {
    cur = `${cur}\n${footer}`;
  }
  pages.push(cur);
  return pages;
}

export async function sendDailyDigest(env, { tg, getChannels, getSetting, setSetting }) {
  // 1. Where to post: the ForceSub channels, or only the test channel while Test Mode is ON
  const forcesubChannels = await getChannels(env, "forcesub");
  const { isTestMode, targets } = await resolveTargetChannels(env, forcesubChannels, getSetting);
  if (!targets.length) {
    return { ok: false, reason: "No ForceSub channels set in /settings." };
  }

  // 2. Always get a valid Bot Username
  let username = await getSetting(env, "bot_username");
  if (!username) {
    const me = await tg(env, "getMe", {});
    if (me.ok && me.result && me.result.username) {
      username = me.result.username;
      if (setSetting) await setSetting(env, "bot_username", username);
    }
  }
  if (!username) {
    return { ok: false, reason: "Could not fetch bot username from Telegram." };
  }

  // 3. Movie & Series batches updated in the last 24 hours.
  //    Test Mode uploads are saved with a "test_" prefix: live digests skip them, test digests show only them.
  const since = Date.now() - 24 * 60 * 60 * 1000;
  const testFilter = isTestMode ? "=" : "!=";
  let batches = [];
  try {
    const rows = await env.DB.prepare(
      "SELECT batch_id, group_key, title, items_json, updated FROM batches " +
      `WHERE updated >= ? AND substr(group_key, 1, 5) ${testFilter} 'test_' ORDER BY updated DESC LIMIT 30`
    ).bind(since).all();
    batches = rows.results || [];
  } catch (err) {
    console.log("Digest query error:", err); // the batches table is created on the first upload
  }

  // 4. Today's IST date
  const istNow = new Date(Date.now() + 330 * 60000);
  const dateLabel = istNow.toUTCString().split(" ").slice(1, 4).join(" ");

  // 5. One entry per title: qualities + audio languages + button-style link
  const entries = [];
  let count = 0;
  for (const b of batches) {
    let items = [];
    try { items = JSON.parse(b.items_json || "[]"); } catch (_) { items = []; }
    if (!items.length) continue; // sample-only batches have nothing to download yet
    count++;

    const isSeries = String(b.group_key || "").replace(/^test_/, "").startsWith("series:");
    const icon = isSeries ? "📺" : "🎬";
    const cleanTitle = String(b.title || "Untitled").replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 120);

    const quals = [];
    const langs = [];
    for (const it of items) {
      if (it.quality && !quals.includes(it.quality)) quals.push(it.quality);
      for (const l of it.audioLangs || []) {
        if (l && !langs.includes(l)) langs.push(l);
      }
    }
    quals.sort(sortQualities);

    const qualTag = quals.length ? ` (${quals.join(" | ")})` : "";
    const langLine = langs.length ? `\n🔊 <i>${esc(langs.join(" + "))}</i>` : "";

    const botUrl = `https://t.me/${username}?start=b${b.batch_id}`;
    const btnLabel = isSeries && items.length > 1
      ? `📥 All ${items.length} Episodes ↗`
      : `📥 Get File ↗`;

    entries.push(
      `<b>${count}. ${icon} ${esc(cleanTitle)}</b><i>${esc(qualTag)}</i>${langLine}\n` +
      `<blockquote>👉 <a href="${botUrl}"><b>${btnLabel}</b></a></blockquote>\n`
    );
  }

  if (!count) {
    return { ok: false, reason: "No new movies or series uploaded in the last 24 hours." };
  }

  // 6. Header, footer ("How to Download" pill) and splitting into messages
  const header =
    (isTestMode ? "🧪 <b>[TEST MODE]</b>\n" : "") +
    `📅 <b>Today's Uploads (${esc(dateLabel)})</b>\n` +
    `<i>Tap any blue button below a title to get the file directly in bot PM:</i>\n`;

  const footerLines = [`🔔 <i>Stay joined for daily 7:00 PM upload updates!</i>`];
  const tutorialUrl = await getSetting(env, "tutorial_url");
  if (tutorialUrl) {
    footerLines.push(`<blockquote>🎬 <a href="${esc(tutorialUrl)}"><b>How to Download (Tutorial) ↗</b></a></blockquote>`);
  }

  const pages = paginate(header, entries, footerLines.join("\n"), MAX_MESSAGE_LEN)
    .map((p, i) => (i === 0 ? p : `📅 <b>Today's Uploads (continued)</b>\n\n${p}`));

  // 7. Send to every target channel
  const cover = await getSetting(env, "cover_lecture");
  let sentCount = 0;

  for (const ch of targets) {
    let firstOk = false;
    for (let i = 0; i < pages.length; i++) {
      let res = null;
      if (i === 0 && cover && pages[0].length <= MAX_CAPTION_LEN) {
        res = await tg(env, "sendPhoto", {
          chat_id: ch.chat_id,
          photo: cover,
          caption: pages[0],
          parse_mode: "HTML",
          protect_content: true,
        });
      }
      if (!res || !res.ok) {
        res = await tg(env, "sendMessage", {
          chat_id: ch.chat_id,
          text: pages[i],
          parse_mode: "HTML",
          disable_web_page_preview: true,
          protect_content: true,
        });
      }
      if (i === 0) firstOk = !!(res && res.ok);
    }
    if (firstOk) sentCount++;
  }

  return { ok: true, sentCount, totalUploads: count, isTestMode };
}

export async function checkAndRunScheduledDigest(env, helpers) {
  const istDate = new Date(Date.now() + 330 * 60000);
  const istHour = istDate.getUTCHours(); // 19 = 7:00 PM IST
  const todayStr = istDate.toISOString().slice(0, 10);

  if (istHour !== 19) return;

  const lastSent = await helpers.getSetting(env, "last_digest_day");
  if (lastSent === todayStr) return;

  await helpers.setSetting(env, "last_digest_day", todayStr);
  await sendDailyDigest(env, helpers);
}
