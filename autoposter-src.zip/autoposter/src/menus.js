// src/menus.js - All /settings menus

import { MAIN_MENU, PLANS, ROLES } from "./config.js";
import { getChannels, getSetting } from "./db.js";
import { getStarPrices, starsEnabled } from "./subscriptions.js";
import { tg } from "./telegram.js";
import { esc, formatDelay } from "./utils.js";

export async function buildRoleMenu(env, role, page = 0) {
  const info = ROLES[role];
  const channels = await getChannels(env, role);

  const perPage = 10;
  const totalPages = Math.max(1, Math.ceil(channels.length / perPage));
  const curPage = Math.max(0, Math.min(page, totalPages - 1));
  const slice = channels.slice(curPage * perPage, (curPage + 1) * perPage);

  let text = `${info.emoji} <b>${info.name}</b> (${channels.length}${info.max ? `/${info.max}` : ""})\n\n${info.help}\n\n`;
  if (channels.length) {
    text += `📄 <b>Page ${curPage + 1} of ${totalPages}</b>\n`;
    text += slice.map((c, idx) => `${curPage * perPage + idx + 1}. ${esc(c.title)} (<code>${c.chat_id}</code>)`).join("\n");
  } else {
    text += "<i>None set yet.</i>";
  }

  const buttons = slice.map((c) => [
    { text: `🗑 Remove ${c.title}`.slice(0, 60), callback_data: `rm:${role}:${curPage}:${c.chat_id}` },
  ]);

  if (totalPages > 1) {
    const nav = [];
    if (curPage > 0) nav.push({ text: "⏪ Prev", callback_data: `role:${role}:${curPage - 1}` });
    if (curPage < totalPages - 1) nav.push({ text: "⏩ Next", callback_data: `role:${role}:${curPage + 1}` });
    if (nav.length) buttons.push(nav);
  }

  if (!info.max || channels.length < info.max) {
    const addLabel = info.multi ? "➕ Add Channel" : channels.length ? "🔄 Change Channel" : "➕ Set Channel";
    buttons.push([{ text: addLabel, callback_data: `add:${role}` }]);
  }
  buttons.push(...BACK_BUTTON);

  return { text, buttons };
}

export async function showRoleMenu(env, chatId, messageId, role, page = 0) {
  const menu = await buildRoleMenu(env, role, page);
  await tg(env, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text: menu.text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: menu.buttons },
  });
}

export async function showMainMenu(env, chatId, messageId) {
  await tg(env, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text: MAIN_MENU.text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: MAIN_MENU.buttons },
  });
}

// ---------- Cover images menu ----------
export async function buildCoverMenu(env, note) {
  const pdf = await getSetting(env, "cover_pdf");
  const lec = await getSetting(env, "cover_lecture");
  let text = "🖼️ <b>Cover Images</b>\n\n" +
    "A cover is the picture shown on each channel post. If none is set, I automatically use the official TMDb/IMDb poster or the file's thumbnail.\n\n" +
    `📄 PDF cover: ${pdf ? "✅ Set" : "❌ Not set"}\n` +
    `🎬 Video/Movie fallback cover: ${lec ? "✅ Set" : "❌ Not set (uses TMDb/IMDb poster)"}`;
  if (note) text += `\n\n${note}`;

  const buttons = [
    [{ text: pdf ? "📄 Change PDF Cover" : "📄 Set PDF Cover", callback_data: "cov:set:pdf" }],
    [{ text: lec ? "🎬 Change Video Cover" : "🎬 Set Video Cover", callback_data: "cov:set:lecture" }],
  ];
  if (pdf) buttons.push([{ text: "🗑 Remove PDF Cover", callback_data: "cov:rm:pdf" }]);
  if (lec) buttons.push([{ text: "🗑 Remove Video Cover", callback_data: "cov:rm:lecture" }]);
  buttons.push(...BACK_BUTTON);
  return { text, buttons };
}

export async function showCoverMenu(env, chatId, messageId, note) {
  const menu = await buildCoverMenu(env, note);
  await tg(env, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text: menu.text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: menu.buttons },
  });
}

export async function buildDeleteMenu(env, note) {
  const rawMins = await getSetting(env, "delete_minutes");
  const mins = rawMins === null ? 5 : parseInt(rawMins, 10);
  let text = "🗑️ <b>File Delete Settings</b>\n\n" +
    "Files sent by the bot can be shared/forwarded by users for the time you choose, and then are automatically deleted from the chat.\n\n" +
    `Current: <b>${formatDelay(mins)}</b>`;
  if (note) text += `\n\n${note}`;

  const choice = (label, value) => ({
    text: (mins === value ? "✅ " : "") + label,
    callback_data: `del:set:${value}`,
  });
  const buttons = [
    [choice("Off", 0), choice("5 min", 5), choice("10 min", 10)],
    [choice("30 min", 30), choice("1 hour", 60), choice("6 hours", 360)],
    [choice("24 hours", 1440), { text: "✏️ Custom", callback_data: "del:custom" }],
    ...BACK_BUTTON,
  ];
  return { text, buttons };
}

export async function showDeleteMenu(env, chatId, messageId, note) {
  const menu = await buildDeleteMenu(env, note);
  await tg(env, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text: menu.text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: menu.buttons },
  });
}

// ---------- IMDb, TMDb, Multi-Quality & Anti-Copyright Menu ----------
export async function buildMetaMenu(env, note) {
  const metaOn = (await getSetting(env, "meta_enabled")) === "1";
  const miOn = (await getSetting(env, "mediainfo_enabled")) !== "0"; // ON by default
  const groupOn = (await getSetting(env, "group_qualities")) !== "0"; // ON by default
  const shieldOn = (await getSetting(env, "shield_redirect")) !== "0"; // ON by default
  const protectOn = (await getSetting(env, "protect_files")) === "1"; // OFF by default so users can forward/share
  const tmdbKey = await getSetting(env, "tmdb_key");
  const omdbKey = await getSetting(env, "omdb_key");
  const sampleUrl = await getSetting(env, "sample_url");

  let text = "🎬 <b>IMDb, TMDb, Series Batching & Shield</b>\n\n" +
    "• <b>Combine Qualities & Series Seasons:</b> Merges 480p, 720p, 1080p, 4K of a Movie or an entire TV Season into ONE channel post. Tapping 720p on a series opens the Jarvis-style Episode Batch list!\n" +
    "• <b>MediaInfo:</b> Extracts audio languages, subtitles, codecs & resolution.\n" +
    "• <b>Redirect Shield:</b> Uses Worker links on channel posts to protect your channel.\n" +
    "• <b>Forward Lock:</b> Keep OFF so users can forward/share files within 5 minutes.\n\n" +
    `🎬 IMDb/TMDb Info: ${metaOn ? "✅ ON" : "❌ OFF"}\n` +
    `🗂 Combine Qualities & Seasons: ${groupOn ? "✅ ON" : "❌ OFF"}\n` +
    `📊 Deep MediaInfo (Audio/Subs): ${miOn ? "✅ ON" : "❌ OFF"}\n` +
    `🛡️ Worker Redirect Shield: ${shieldOn ? "✅ ON" : "❌ OFF"}\n` +
    `🔒 Lock File Forwarding: ${protectOn ? "✅ ON (No Share)" : "❌ OFF (Users Can Share)"}\n\n` +
    `TMDb Key: ${tmdbKey ? "<code>" + esc(tmdbKey.slice(0, 4)) + "••••</code>" : "<i>not set</i>"}\n` +
    `OMDb (IMDb) Key: ${omdbKey ? "<code>" + esc(omdbKey.slice(0, 4)) + "••••</code>" : "<i>not set</i>"}\n` +
    `🎬 Sample Channel Link: ${sampleUrl ? esc(sampleUrl) : "<i>not set</i>"}`;
  if (note) text += `\n\n${note}`;

  const buttons = [
    [{ text: metaOn ? "🎬 IMDb/TMDb: ON" : "🎬 IMDb/TMDb: OFF (Tap to ON)", callback_data: "meta:toggle" }],
    [{ text: groupOn ? "🗂 Combine Qualities/Seasons: ON" : "🗂 Combine Qualities/Seasons: OFF", callback_data: "meta:grouptoggle" }],
    [{ text: miOn ? "📊 MediaInfo (Audio/Subs): ON" : "📊 MediaInfo: OFF", callback_data: "meta:mitoggle" }],
    [
      { text: shieldOn ? "🛡️ Link Shield: ON" : "🛡️ Link Shield: OFF", callback_data: "meta:shieldtoggle" },
      { text: protectOn ? "🔒 Forward Lock: ON" : "🔓 Forward Lock: OFF", callback_data: "meta:prottoggle" },
    ],
    [
      { text: "🔑 Set TMDb Key", callback_data: "meta:tmdb" },
      { text: "🔑 Set OMDb Key", callback_data: "meta:omdb" },
    ],
    [{ text: sampleUrl ? "🎬 Change Sample Channel Link" : "🎬 Set Sample Channel Link", callback_data: "meta:sample" }],
  ];
  if (sampleUrl) buttons.push([{ text: "🗑 Remove Sample Link", callback_data: "meta:rmsample" }]);
  buttons.push(...BACK_BUTTON);
  return { text, buttons };
}

// ---------- Shortlink & Tutorial settings menu ----------
export async function buildShortlinkMenu(env, note) {
  const on = (await getSetting(env, "shortlink_enabled")) === "1";
  const domain = await getSetting(env, "shortlink_domain");
  const key = await getSetting(env, "shortlink_key");
  const tut = await getSetting(env, "tutorial_url");
  const vpassOn = (await getSetting(env, "vpass_enabled")) !== "0";

  let text =
    "🔗 <b>Shortlink & Tutorial Settings</b>\n" +
    "Users pass a copy-protected shortlink before they get a file or season batch.\n\n";
  text += `Status: ${on ? "✅ ON (Anti-Copy Mini App Shield Active)" : "❌ OFF"}\n`;
  text += `⏱️ 6-Hour Verify Pass: ${vpassOn ? "🟢 <b>ON (Verify once for all movies)</b>" : "🔴 <b>OFF (Verify every movie)</b>"}\n`;
  text += `Domain: ${domain ? esc(domain) : "<i>not set</i>"}\n`;
  text += `API Key: ${key ? "<code>" + esc(key.slice(0, 6)) + "••••••</code>" : "<i>not set</i>"}\n`;
  text += `How to Verify Tutorial: ${tut ? esc(tut) : "<i>not set</i>"}`;
  if (note) text += `\n\n${note}`;

  const buttons = [
    [{ text: on ? "🔴 Turn OFF" : "🟢 Turn ON", callback_data: "sl:toggle" }],
    [{
      text: vpassOn ? "⏱️ 6-Hour Pass: 🟢 ON (Tap to Turn OFF)" : "⏱️ 6-Hour Pass: 🔴 OFF (Tap to Turn ON)",
      callback_data: "sl:toggle_vpass",
    }],
    [{ text: "🌐 Set Domain", callback_data: "sl:domain" }, { text: "🔑 Set API Key", callback_data: "sl:key" }],
    [{ text: "🎬 Set Tutorial Link (How to Verify)", callback_data: "sl:tutorial" }],
  ];
  if (tut) buttons.push([{ text: "🗑️ Remove Tutorial Link", callback_data: "sl:rmtut" }]);
  buttons.push(...BACK_BUTTON);
  return { text, buttons };
}

export async function showShortlinkMenu(env, chatId, messageId, note) {
  const menu = await buildShortlinkMenu(env, note);
  await tg(env, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text: menu.text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    reply_markup: { inline_keyboard: menu.buttons },
  });
}

export async function buildPayMenu(env, note) {
  const upi = await getSetting(env, "upi_id");
  const name = await getSetting(env, "upi_name");
  const waiting = await env.DB.prepare("SELECT COUNT(*) AS n FROM payments WHERE status = 'submitted'").first();
  let text = "💳 <b>Payments (UPI)</b>\n\n" +
    "Customers pay your UPI ID from the Mini App, then send their reference number (UTR). " +
    "You approve each payment after checking your bank or UPI app.\n\n" +
    `UPI ID: ${upi ? `<code>${esc(upi)}</code>` : "<i>not set</i>"}\n` +
    `Payee name: ${name ? esc(name) : "<i>not set (shows Premium)</i>"}\n` +
    `Waiting for approval: ${waiting.n}\n\n<b>Plans</b>\n` +
    Object.values(PLANS).map((p) => `${p.name}: ₹${p.price}`).join("\n");
  const stars = await getStarPrices(env);
  const starsOn = await starsEnabled(env);
  text += `\n\n⭐ <b>Telegram Stars: ${starsOn ? "ON" : "OFF"}</b>\n` +
    Object.entries(PLANS).map(([k, p]) => `${p.name}: ${stars[k]} Stars`).join("\n") +
    "\nStars payments are confirmed by Telegram automatically.";
  if (note) text += `\n\n${note}`;
  const buttons = [
    [{ text: starsOn ? "⭐ Stars: ON (tap to turn off)" : "⭐ Stars: OFF (tap to turn on)", callback_data: "pay:startoggle" }],
    [{ text: "⭐ Set Star Prices", callback_data: "pay:stars" }],
    [{ text: "🆔 Set UPI ID", callback_data: "pay:upi" }],
    [{ text: "📝 Set Payee Name", callback_data: "pay:name" }],
    ...BACK_BUTTON,
  ];
  return { text, buttons };
}
