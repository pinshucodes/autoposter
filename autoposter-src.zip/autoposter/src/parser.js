// src/parser.js - Filename / quality / audio / season-episode parser


// ---------- Filename, Quality, Audio & Season/Episode Parser ----------
export function parseMediaFilename(rawName, rawCaption) {
  const full = `${rawName || ""} ${rawCaption || ""}`;
  const rawFirstLine = (rawName || (rawCaption || "").split("\n")[0] || "Untitled")
    .replace(/\.[^.]+$/, "")
    .replace(/[._]+/g, " ")
    .replace(/^(\[@[^\]]+\]|\[[^\]]+\]|\(@[^)]+\))\s*/g, "")
    .trim();

  let isSeries = false;
  let season = null;
  let episode = null;

  const seMatch =
    full.match(/\bS(\d{1,2})[\s._-]*E(?:P)?(\d{1,3})\b/i) ||
    full.match(/\bSeason[\s._-]*(\d{1,2})[\s._-]*Episode[\s._-]*(\d{1,3})\b/i);
  const epRangeMatch = full.match(/\bS(\d{1,2})[\s._-]*E(\d{1,3})[\s._-]*[-~][\s._-]*E?(\d{1,3})\b/i);
  const sOnlyMatch =
    full.match(/\bS(\d{1,2})\b(?![\s._-]*E\d)/i) ||
    full.match(/\bSeason[\s._-]*(\d{1,2})\b/i);
  const epOnlyMatch = full.match(/\b(?:EP|Episode)[\s._-]*(\d{1,3})\b/i);

  if (seMatch) {
    isSeries = true;
    season = parseInt(seMatch[1], 10);
    episode = parseInt(seMatch[2], 10);
  } else if (epRangeMatch) {
    isSeries = true;
    season = parseInt(epRangeMatch[1], 10);
    episode = parseInt(epRangeMatch[2], 10);
  } else if (sOnlyMatch) {
    isSeries = true;
    season = parseInt(sOnlyMatch[1], 10);
    if (epOnlyMatch) episode = parseInt(epOnlyMatch[1], 10);
  } else if (epOnlyMatch) {
    isSeries = true;
    season = 1;
    episode = parseInt(epOnlyMatch[1], 10);
  }

  let quality = "HD";
  if (/\b(2160p|4k|uhd)\b/i.test(full)) quality = "2160p 4K";
  else if (/\b1440p\b/i.test(full)) quality = "1440p";
  else if (/\b1080p\b/i.test(full)) quality = "1080p";
  else if (/\b720p\b/i.test(full)) quality = "720p";
  else if (/\b480p\b/i.test(full)) quality = "480p";
  else if (/\b360p\b/i.test(full)) quality = "360p";

  let source = "";
  if (/\bblu[\s._-]?ray|bdrip|brrip\b/i.test(full)) source = "BluRay";
  else if (/\bweb[\s._-]?dl\b/i.test(full)) source = "WEB-DL";
  else if (/\bweb[\s._-]?rip\b/i.test(full)) source = "WEBRip";
  else if (/\bhdrip\b/i.test(full)) source = "HDRip";
  else if (/\bhdcam|camrip\b/i.test(full)) source = "HDCAM";

  let vCodec = "";
  if (/\b(x265|h\.?265|hevc)\b/i.test(full)) vCodec = "HEVC x265";
  else if (/\b(x264|h\.?264|avc)\b/i.test(full)) vCodec = "x264";
  else if (/\bav1\b/i.test(full)) vCodec = "AV1";

  let aCodec = "";
  if (/\batmos\b/i.test(full)) aCodec = "Atmos";
  else if (/\b(ddp|eac3|dd\+|5\.1)\b/i.test(full)) aCodec = "DD+ 5.1";
  else if (/\baac\b/i.test(full)) aCodec = "AAC";

  const langMap = [
    [/\bhindi\b|\bhin\b/i, "Hindi"],
    [/\benglish\b|\beng\b/i, "English"],
    [/\btamil\b|\btam\b/i, "Tamil"],
    [/\btelugu\b|\btel\b/i, "Telugu"],
    [/\bmalayalam\b|\bmal\b/i, "Malayalam"],
    [/\bkannada\b|\bkan\b/i, "Kannada"],
    [/\bbengali\b|\bben\b/i, "Bengali"],
    [/\bmarathi\b|\bmar\b/i, "Marathi"],
    [/\bpunjabi\b|\bpun\b/i, "Punjabi"],
    [/\bkorean\b|\bkor\b/i, "Korean"],
    [/\bjapanese\b|\bjap\b|\bjpn\b/i, "Japanese"],
    [/\bspanish\b|\bspa\b/i, "Spanish"],
    [/\brussian\b|\brus\b/i, "Russian"],
    [/\bdual[\s._-]*audio\b/i, "Dual Audio"],
    [/\bmulti[\s._-]*audio\b/i, "Multi Audio"],
  ];
  const audioLangs = [];
  for (const [rx, label] of langMap) {
    if (rx.test(full) && !audioLangs.includes(label)) audioLangs.push(label);
  }

  let year = null;
  const yearMatch = rawFirstLine.match(/\b(19\d{2}|20\d{2})\b/);
  if (yearMatch) year = yearMatch[1];

  // Strip "Sample", languages, qualities, and tags so Sample & all Languages share the EXACT same groupKey!
  let cleanTitle = rawFirstLine
    .replace(/\bS\d{1,2}[\s._-]*E(?:P)?\d{1,3}.*$/i, "")
    .replace(/\bS\d{1,2}\b.*$/i, "")
    .replace(/\bSeason[\s._-]*\d{1,2}.*$/i, "")
    .replace(/\b(?:EP|Episode)[\s._-]*\d{1,3}.*$/i, "")
    .replace(/\b(19\d{2}|20\d{2})\b.*$/, "")
    .replace(/\b(sample|trailer|teaser|promo|hq|proper|repack|2160p|1440p|1080p|720p|480p|360p|4k|uhd|web-?dl|web-?rip|bluray|bdrip|brrip|hdrip|hdcam|camrip|x264|x265|h264|h265|hevc|avc|10bit|dual|multi|hindi|english|tamil|telugu|malayalam|kannada|bengali|marathi|punjabi|korean|japanese|spanish|russian|hin|eng|tam|tel|mal|kan|esub|esubs|aac|ddp|eac3|atmos).*$/i, "")
    .replace(/[()[\]\-_.:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (!cleanTitle) cleanTitle = rawFirstLine.slice(0, 40).trim() || "Untitled";

  const slug = cleanTitle.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  const groupKey = isSeries
    ? `series:${slug}:${year || "na"}:s${String(season || 1).padStart(2, "0")}`
    : `movie:${slug}:${year || "na"}`;

  return {
    cleanTitle,
    displayFileName: rawFirstLine,
    year,
    isSeries,
    season: isSeries ? (season || 1) : null,
    episode,
    quality,
    source,
    vCodec,
    aCodec,
    audioLangs,
    groupKey,
  };
}
